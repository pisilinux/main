These icons were taken from http://www.famfamfam.com/lab/icons/flags/

Licensed under the following conditions:

"These flag icons are available for free use for any purpose with no
requirement for attribution."

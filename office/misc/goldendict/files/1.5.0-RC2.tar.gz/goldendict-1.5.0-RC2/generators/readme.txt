This directory holds various generators to generate some code/data. We ship
that generated content as part of the source code to simplify compilation, so
there's no need for the end user to regenerate anything. A developer making
changes to the relevant data files would need this, though,

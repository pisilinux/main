<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it_IT">
<context>
    <name>QWidget</name>
    <message>
        <source>*</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QShortcut</name>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>CD</source>
        <translation>CD</translation>
    </message>
    <message>
        <source>Go</source>
        <translation>Vai</translation>
    </message>
    <message>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Sù</translation>
    </message>
    <message>
        <source>Alt</source>
        <translation>Alt</translation>
    </message>
    <message>
        <source>F%1</source>
        <translation>F%1</translation>
    </message>
    <message>
        <source>DOS</source>
        <translation>DOS</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Canc</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Taglia</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Fine</translation>
    </message>
    <message>
        <source>Esc</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Ins</source>
        <translation>Ins</translation>
    </message>
    <message>
        <source>Tab</source>
        <translation>Tab</translation>
    </message>
    <message>
        <source>WWW</source>
        <translation>WWW</translation>
    </message>
    <message>
        <source>Yes</source>
        <translation>Sì</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <source>Away</source>
        <translation>Assente</translation>
    </message>
    <message>
        <source>Book</source>
        <translation>Libro</translation>
    </message>
    <message>
        <source>Call</source>
        <translation>Chiama</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Ctrl</source>
        <translation>Ctrl</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Giù</translation>
    </message>
    <message>
        <source>Flip</source>
        <translation>Inverti</translation>
    </message>
    <message>
        <source>Game</source>
        <translation>Gioco</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Guida</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Inizio</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Sinistra</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <source>Meta</source>
        <translation>Meta</translation>
    </message>
    <message>
        <source>News</source>
        <translation>Novità</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>PgSù</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Invia</translation>
    </message>
    <message>
        <source>Shop</source>
        <translation>Negozio</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Interrompi</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Durata</translation>
    </message>
    <message>
        <source>XFer</source>
        <translation>XFer</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <source>Split Screen</source>
        <translation>Dividi schermo</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Pulisci</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Eject</source>
        <translation>Espelli</translation>
    </message>
    <message>
        <source>Enter</source>
        <translation>Invio</translation>
    </message>
    <message>
        <source>Kanji</source>
        <translation>Kanji</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Musica</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Incolla</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Phone</source>
        <translation>Telefono</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Stampa</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Rispondi</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Destra</translation>
    </message>
    <message>
        <source>Shift</source>
        <translation>MAIUSCOLE</translation>
    </message>
    <message>
        <source>Sleep</source>
        <translation>Sospendi</translation>
    </message>
    <message>
        <source>Space</source>
        <translation>Spazio</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Strumenti</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Hiragana</source>
        <translation>Hiragana</translation>
    </message>
    <message>
        <source>Wireless</source>
        <translation>Wireless</translation>
    </message>
    <message>
        <source>Media Record</source>
        <translation>Registra</translation>
    </message>
    <message>
        <source>Multiple Candidate</source>
        <translation>Candidato multiplo</translation>
    </message>
    <message>
        <source>Zenkaku</source>
        <translation>Zenkaku</translation>
    </message>
    <message>
        <source>Print Screen</source>
        <translation>Stampa schermata</translation>
    </message>
    <message>
        <source>Audio Rewind</source>
        <translation>Riavvolgi audio</translation>
    </message>
    <message>
        <source>Audio Repeat</source>
        <translation>Ripeti audio</translation>
    </message>
    <message>
        <source>Toggle Call/Hangup</source>
        <translation>Alterna Chiama/Riaggancia</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Ingrandisci</translation>
    </message>
    <message>
        <source>Camera Shutter</source>
        <translation>Otturatore fotocamera</translation>
    </message>
    <message>
        <source>Ultra Wide Band</source>
        <translation>Banda ultra larga</translation>
    </message>
    <message>
        <source>Hangul Special</source>
        <translation>Hangul Special</translation>
    </message>
    <message>
        <source>Treble Down</source>
        <translation>Abbassa gli alti</translation>
    </message>
    <message>
        <source>Scroll Lock</source>
        <translation>Blocca scorrimento</translation>
    </message>
    <message>
        <source>Media Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Word Processor</source>
        <translation>Elaboratore di testi</translation>
    </message>
    <message>
        <source>Volume Down</source>
        <translation>Abbassa volume</translation>
    </message>
    <message>
        <source>Volume Mute</source>
        <translation>Silenzia</translation>
    </message>
    <message>
        <source>Kana Shift</source>
        <translation>Kana MAIUSCOLE</translation>
    </message>
    <message>
        <source>Media Previous</source>
        <translation>Traccia precedente</translation>
    </message>
    <message>
        <source>Home Page</source>
        <translation>Pagina iniziale</translation>
    </message>
    <message>
        <source>Meeting</source>
        <translation>Riunione</translation>
    </message>
    <message>
        <source>Volume Up</source>
        <translation>Alza volume</translation>
    </message>
    <message>
        <source>Menu PB</source>
        <translation>Menu PB</translation>
    </message>
    <message>
        <source>Keyboard Brightness Up</source>
        <translation>Aumenta la luminosità della tastiera</translation>
    </message>
    <message>
        <source>Hangul PostHanja</source>
        <translation>Hangul PostHanja</translation>
    </message>
    <message>
        <source>Kana Lock</source>
        <translation>Blocca Kana</translation>
    </message>
    <message>
        <source>Community</source>
        <translation>Comunità</translation>
    </message>
    <message>
        <source>Launch (6)</source>
        <translation>Avvia (6)</translation>
    </message>
    <message>
        <source>Launch (7)</source>
        <translation>Avvia (7)</translation>
    </message>
    <message>
        <source>Launch (8)</source>
        <translation>Avvia (8)</translation>
    </message>
    <message>
        <source>Launch (9)</source>
        <translation>Avvia (9)</translation>
    </message>
    <message>
        <source>Launch (2)</source>
        <translation>Avvia (2)</translation>
    </message>
    <message>
        <source>Launch (3)</source>
        <translation>Avvia (3)</translation>
    </message>
    <message>
        <source>Launch (4)</source>
        <translation>Avvia (4)</translation>
    </message>
    <message>
        <source>Launch (5)</source>
        <translation>Avvia (5)</translation>
    </message>
    <message>
        <source>Launch (0)</source>
        <translation>Avvia (0)</translation>
    </message>
    <message>
        <source>Launch (1)</source>
        <translation>Avvia (1)</translation>
    </message>
    <message>
        <source>Launch (F)</source>
        <translation>Avvia (F)</translation>
    </message>
    <message>
        <source>Launch (B)</source>
        <translation>Avvia (B)</translation>
    </message>
    <message>
        <source>Launch (C)</source>
        <translation>Avvia (C)</translation>
    </message>
    <message>
        <source>Launch (D)</source>
        <translation>Avvia (D)</translation>
    </message>
    <message>
        <source>Launch (E)</source>
        <translation>Avvia (E)</translation>
    </message>
    <message>
        <source>Launch (A)</source>
        <translation>Avvia (A)</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Escape</source>
        <translation>Esc</translation>
    </message>
    <message>
        <source>Audio Random Play</source>
        <translation>Riproduci brani casualmente</translation>
    </message>
    <message>
        <source>Hangul</source>
        <translation>Hangul</translation>
    </message>
    <message>
        <source>Hangup</source>
        <translation>Riaggancia</translation>
    </message>
    <message>
        <source>Henkan</source>
        <translation>Henkan</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Inserisci</translation>
    </message>
    <message>
        <source>Home Office</source>
        <translation>Casa e ufficio</translation>
    </message>
    <message>
        <source>Last Number Redial</source>
        <translation>Ultimo numero chiamato</translation>
    </message>
    <message>
        <source>Logoff</source>
        <translation>Disconnettiti</translation>
    </message>
    <message>
        <source>Market</source>
        <translation>Mercato</translation>
    </message>
    <message>
        <source>Massyo</source>
        <translation>Massyo</translation>
    </message>
    <message>
        <source>Bass Boost</source>
        <translation>Incremento bassi</translation>
    </message>
    <message>
        <source>Option</source>
        <translation>Opzione</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>PgGiù</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Ricarica</translation>
    </message>
    <message>
        <source>Return</source>
        <translation>Invio</translation>
    </message>
    <message>
        <source>Romaji</source>
        <translation>Romaji</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>Seleziona</translation>
    </message>
    <message>
        <source>SysReq</source>
        <translation>SysReq</translation>
    </message>
    <message>
        <source>Travel</source>
        <translation>Viaggia</translation>
    </message>
    <message>
        <source>NumLock</source>
        <translation>BlocNum</translation>
    </message>
    <message>
        <source>Audio Forward</source>
        <translation>Avannza audio</translation>
    </message>
    <message>
        <source>WebCam</source>
        <translation>WebCam</translation>
    </message>
    <message>
        <source>Hiragana Katakana</source>
        <translation>Hiragana Katakana</translation>
    </message>
    <message>
        <source>Top Menu</source>
        <translation>Menu in alto</translation>
    </message>
    <message>
        <source>ScrollLock</source>
        <translation>BloccaScorrimento</translation>
    </message>
    <message>
        <source>Hot Links</source>
        <translation>Collegamenti caldi</translation>
    </message>
    <message>
        <source>Audio Cycle Track</source>
        <translation>Ripeti ciclicamente</translation>
    </message>
    <message>
        <source>Context1</source>
        <translation>Contesto1</translation>
    </message>
    <message>
        <source>Context2</source>
        <translation>Contesto2</translation>
    </message>
    <message>
        <source>Context3</source>
        <translation>Contesto3</translation>
    </message>
    <message>
        <source>Context4</source>
        <translation>Contesto4</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Riduci</translation>
    </message>
    <message>
        <source>Page Up</source>
        <translation>Pagina sù</translation>
    </message>
    <message>
        <source>Open URL</source>
        <translation>Apri URL</translation>
    </message>
    <message>
        <source>iTouch</source>
        <translation>iTouch</translation>
    </message>
    <message>
        <source>Previous Candidate</source>
        <translation>Candidato precedente</translation>
    </message>
    <message>
        <source>Toggle Media Play/Pause</source>
        <translation>Alterna Riproduci/Pausa</translation>
    </message>
    <message>
        <source>Caps Lock</source>
        <translation>BLOCCO MAIUSCOLE</translation>
    </message>
    <message>
        <source>Eisu Shift</source>
        <translation>Eisu MAIUSCOLE</translation>
    </message>
    <message>
        <source>Code input</source>
        <translation>Inserisci codice</translation>
    </message>
    <message>
        <source>Camera Focus</source>
        <translation>Messa a fuoco fotocamera</translation>
    </message>
    <message>
        <source>Adjust Brightness</source>
        <translation>Regola la luminosità</translation>
    </message>
    <message>
        <source>Spreadsheet</source>
        <translation>Foglio di calcolo</translation>
    </message>
    <message>
        <source>Eisu toggle</source>
        <translation>Alterna Eisu</translation>
    </message>
    <message>
        <source>Keyboard Brightness Down</source>
        <translation>Abbassa la luminosità della tastiera</translation>
    </message>
    <message>
        <source>Clear Grab</source>
        <translation>Elimina la cattura</translation>
    </message>
    <message>
        <source>Monitor Brightness Up</source>
        <translation>Aumenta la luminosità del monitor</translation>
    </message>
    <message>
        <source>System Request</source>
        <translation>Sistema richiesto</translation>
    </message>
    <message>
        <source>CapsLock</source>
        <translation>BLOCCOMAIUSCOLE</translation>
    </message>
    <message>
        <source>Backtab</source>
        <translation>Tab indietro</translation>
    </message>
    <message>
        <source>Bass Up</source>
        <translation>Alza i bassi</translation>
    </message>
    <message>
        <source>Battery</source>
        <translation>Batteria</translation>
    </message>
    <message>
        <source>Katakana</source>
        <translation>Katakana</translation>
    </message>
    <message>
        <source>Refresh</source>
        <translation>Aggiorna</translation>
    </message>
    <message>
        <source>Hibernate</source>
        <translation>Iberna</translation>
    </message>
    <message>
        <source>Application Left</source>
        <translation>Applicazione sinistra</translation>
    </message>
    <message>
        <source>Voice Dial</source>
        <translation>Composizione vocale</translation>
    </message>
    <message>
        <source>Browser</source>
        <translation>Navigatore</translation>
    </message>
    <message>
        <source>Keyboard Menu</source>
        <translation>Menu tastiera</translation>
    </message>
    <message>
        <source>Back Forward</source>
        <translation>Arretra Avanza</translation>
    </message>
    <message>
        <source>Launch Mail</source>
        <translation>Avvia email</translation>
    </message>
    <message>
        <source>Keyboard Light On/Off</source>
        <translation>Tastiera illuminata sì/no</translation>
    </message>
    <message>
        <source>Backspace</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <source>Bass Down</source>
        <translation>Abbassa i bassi</translation>
    </message>
    <message>
        <source>Mail Forward</source>
        <translation>Intoltra email</translation>
    </message>
    <message>
        <source>Messenger</source>
        <translation>Messaggeria istantanea</translation>
    </message>
    <message>
        <source>Hangul Banja</source>
        <translation>Hangul Banja</translation>
    </message>
    <message>
        <source>Hangul Hanja</source>
        <translation>Hangul Hanja</translation>
    </message>
    <message>
        <source>Standby</source>
        <translation>Attesa</translation>
    </message>
    <message>
        <source>Hangul Start</source>
        <translation>Avvio Hangul</translation>
    </message>
    <message>
        <source>Rotation KB</source>
        <translation>Rotazione KB</translation>
    </message>
    <message>
        <source>Rotation PB</source>
        <translation>Rotazione PB</translation>
    </message>
    <message>
        <source>Documents</source>
        <translation>Documenti</translation>
    </message>
    <message>
        <source>Calculator</source>
        <translation>Calcolatrice</translation>
    </message>
    <message>
        <source>Support</source>
        <translation>Supporto</translation>
    </message>
    <message>
        <source>Suspend</source>
        <translation>Sospendi</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Schermo</translation>
    </message>
    <message>
        <source>Hangul Romaja</source>
        <translation>Hangul Romaja</translation>
    </message>
    <message>
        <source>My Sites</source>
        <translation>I miei siti</translation>
    </message>
    <message>
        <source>Rotate Windows</source>
        <translation>Ruota finestra</translation>
    </message>
    <message>
        <source>Touroku</source>
        <translation>Touroku</translation>
    </message>
    <message>
        <source>Zenkaku Hankaku</source>
        <translation>Zenkaku Hankaku</translation>
    </message>
    <message>
        <source>Hangul Jeonja</source>
        <translation>Hangul Jeonja</translation>
    </message>
    <message>
        <source>Treble Up</source>
        <translation>Alza gli alti</translation>
    </message>
    <message>
        <source>Subtitle</source>
        <translation>Sottotitoli</translation>
    </message>
    <message>
        <source>Hangul Jamo</source>
        <translation>Hangul Jamo</translation>
    </message>
    <message>
        <source>Bluetooth</source>
        <translation>Bluetooth</translation>
    </message>
    <message>
        <source>Muhenkan</source>
        <translation>Muhenkan</translation>
    </message>
    <message>
        <source>Num Lock</source>
        <translation>Bloc Num</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Salva schermo</translation>
    </message>
    <message>
        <source>Number Lock</source>
        <translation>Blocca tastierino numerico</translation>
    </message>
    <message>
        <source>Spellchecker</source>
        <translation>Correttore ortografico</translation>
    </message>
    <message>
        <source>Hangul PreHanja</source>
        <translation>Hangul PreHanja</translation>
    </message>
    <message>
        <source>Terminal</source>
        <translation>Terminale</translation>
    </message>
    <message>
        <source>Add Favorite</source>
        <translation>Aggiungi ai preferiti</translation>
    </message>
    <message>
        <source>Finance</source>
        <translation>Finanza</translation>
    </message>
    <message>
        <source>Task Panel</source>
        <translation>Pannello dei compiti</translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation>Preferiti</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Avanza</translation>
    </message>
    <message>
        <source>Page Down</source>
        <translation>Pagina giù</translation>
    </message>
    <message>
        <source>Wake Up</source>
        <translation>Risveglio</translation>
    </message>
    <message>
        <source>Power Off</source>
        <translation>Spegnimento</translation>
    </message>
    <message>
        <source>LightBulb</source>
        <translation>Lampadina</translation>
    </message>
    <message>
        <source>Hankaku</source>
        <translation>Hankaku</translation>
    </message>
    <message>
        <source>Hangul End</source>
        <translation>Fine Hangul</translation>
    </message>
    <message>
        <source>Monitor Brightness Down</source>
        <translation>Abbassa la luminosità del monitor</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Cronologia</translation>
    </message>
    <message>
        <source>Media Play</source>
        <translation>Riproduci</translation>
    </message>
    <message>
        <source>Media Stop</source>
        <translation>Interrompi</translation>
    </message>
    <message>
        <source>Media Next</source>
        <translation>Traccia successiva</translation>
    </message>
    <message>
        <source>Launch Media</source>
        <translation>Avvia traccia multimediale</translation>
    </message>
    <message>
        <source>Application Right</source>
        <translation>Applicazione destra</translation>
    </message>
    <message>
        <source>Pictures</source>
        <translation>Immmagini</translation>
    </message>
</context>
<context>
    <name>Q3TabDialog</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Guida</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Defaults</source>
        <translation>Preimpostati</translation>
    </message>
</context>
<context>
    <name>QDialogButtonBox</name>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <source>&amp;No</source>
        <translation>&amp;No</translation>
    </message>
    <message>
        <source>&amp;Yes</source>
        <translation>&amp;Sì</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Guida</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Salva</translation>
    </message>
    <message>
        <source>Abort</source>
        <translation>Interrompi</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Azzera</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation>Riprova</translation>
    </message>
    <message>
        <source>Restore Defaults</source>
        <translation>Ripristina i valori preimpostati</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Ignore</source>
        <translation>Ignora</translation>
    </message>
    <message>
        <source>Close without Saving</source>
        <translation>Chiudi senza salvare</translation>
    </message>
    <message>
        <source>N&amp;o to All</source>
        <translation>N&amp;o a tutti</translation>
    </message>
    <message>
        <source>Save All</source>
        <translation>Salva tutto</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annulla</translation>
    </message>
    <message>
        <source>Discard</source>
        <translation>Rifiuta</translation>
    </message>
    <message>
        <source>Yes to &amp;All</source>
        <translation>S&amp;ì a tutti</translation>
    </message>
    <message>
        <source>Don&apos;t Save</source>
        <translation>Non salvare</translation>
    </message>
</context>
<context>
    <name>QPrintPreviewDialog</name>
    <message>
        <source>%1%</source>
        <translation>%1%</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Anteprima di stampa</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Stampa</translation>
    </message>
    <message>
        <source>Fit page</source>
        <translation>Adatta zoom alla pagina</translation>
    </message>
    <message>
        <source>Zoom in</source>
        <translation>Ingrandisci</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Orizzontale</translation>
    </message>
    <message>
        <source>Zoom out</source>
        <translation>Riduci</translation>
    </message>
    <message>
        <source>Fit width</source>
        <translation>Adatta zoom in larghezza</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Verticale</translation>
    </message>
    <message>
        <source>Page Setup</source>
        <translation>Imposta pagina</translation>
    </message>
    <message>
        <source>Page setup</source>
        <translation>Imposta pagina</translation>
    </message>
    <message>
        <source>Show overview of all pages</source>
        <translation>Mostra panoramica di tutte le pagine</translation>
    </message>
    <message>
        <source>First page</source>
        <translation>Vai alla prima pagina</translation>
    </message>
    <message>
        <source>Last page</source>
        <translation>Vai all&apos;ultima pagina</translation>
    </message>
    <message>
        <source>Show single page</source>
        <translation>Mostra pagina singola</translation>
    </message>
    <message>
        <source>Export to PDF</source>
        <translation>Esporta come PDF</translation>
    </message>
    <message>
        <source>Previous page</source>
        <translation>Vai alla pagina precedente</translation>
    </message>
    <message>
        <source>Next page</source>
        <translation>Vai alla pagina successiva</translation>
    </message>
    <message>
        <source>Show facing pages</source>
        <translation>Mostra pagine affiancate</translation>
    </message>
    <message>
        <source>Export to PostScript</source>
        <translation>Esporta come PostScript</translation>
    </message>
</context>
<context>
    <name>QWebPage</name>
    <message>
        <source>Top</source>
        <translation>In alto</translation>
    </message>
    <message>
        <source>Unknown</source>
        <comment>Unknown filesize FTP directory listing item</comment>
        <translation>Sconosciute</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>Allinea a destra</translation>
    </message>
    <message>
        <source>Insert a new paragraph</source>
        <translation>Inserisci un nuovo paragrafo</translation>
    </message>
    <message>
        <source>Strikethrough</source>
        <translation>Barrato</translation>
    </message>
    <message>
        <source>Recent searches</source>
        <comment>label for first item in the menu that appears when clicking on the search field image, used as embedded menu title</comment>
        <translation>Ricerche recenti</translation>
    </message>
    <message>
        <source>Stop</source>
        <comment>Stop context menu item</comment>
        <translation>Interrompi</translation>
    </message>
    <message>
        <source>Select to the start of the block</source>
        <translation>Seleziona all&apos;inizio del blocco</translation>
    </message>
    <message>
        <source>No Guesses Found</source>
        <comment>No Guesses Found context menu item</comment>
        <translation>Nessun ospite trovato</translation>
    </message>
    <message>
        <source>Move the cursor to the end of the block</source>
        <translation>Sposta il cursore alla fine del blocco</translation>
    </message>
    <message>
        <source>Fullscreen Button</source>
        <comment>Media controller element</comment>
        <translation>Passa a schermo intero</translation>
    </message>
    <message>
        <source>Select to the start of the line</source>
        <translation>Seleziona all&apos;inizio della linea</translation>
    </message>
    <message>
        <source>This is a searchable index. Enter search keywords: </source>
        <comment>text that appears at the start of nearly-obsolete web pages in the form of a &apos;searchable index&apos;</comment>
        <translation>Questo è un indice consultabile. Inserire le parole chiave:</translation>
    </message>
    <message>
        <source>Justify</source>
        <translation>Giustificato</translation>
    </message>
    <message>
        <source>Direction</source>
        <comment>Writing direction context sub-menu item</comment>
        <translation>Direzione</translation>
    </message>
    <message>
        <source>Delete to the start of the word</source>
        <translation>Elimina all&apos;inizio della parola</translation>
    </message>
    <message>
        <source>Unmute audio tracks</source>
        <comment>Media controller element</comment>
        <translation>Riattiva l&apos;audio delle tracce dal silenzio</translation>
    </message>
    <message>
        <source>Seek Forward Button</source>
        <comment>Media controller element</comment>
        <translation>Avanza ricerca</translation>
    </message>
    <message>
        <source>Left to Right</source>
        <comment>Left to Right context menu item</comment>
        <translation>Da sinistra a destra</translation>
    </message>
    <message>
        <source>Move the cursor to the next word</source>
        <translation>Sposta il cursore all&apos;inizio della parola</translation>
    </message>
    <message>
        <source>Move the cursor to the next line</source>
        <translation>Sposta il cursore all&apos;inizio della linea</translation>
    </message>
    <message>
        <source>JavaScript Alert - %1</source>
        <translation>Allerta JavaScript - %1</translation>
    </message>
    <message>
        <source>Right to Left</source>
        <comment>Right to Left context menu item</comment>
        <translation>Da destra a sinistra</translation>
    </message>
    <message>
        <source>Scroll down</source>
        <translation>Scorri verso il basso</translation>
    </message>
    <message>
        <source>Scroll here</source>
        <translation>Scorri qui</translation>
    </message>
    <message>
        <source>Scroll left</source>
        <translation>Scorri verso sinistra</translation>
    </message>
    <message>
        <source>Go Back</source>
        <comment>Back context menu item</comment>
        <translation>Precedente</translation>
    </message>
    <message>
        <source>Search The Web</source>
        <comment>Search The Web context menu item</comment>
        <translation>Cerca nel web</translation>
    </message>
    <message>
        <source>Unmute Button</source>
        <comment>Media controller element</comment>
        <translation>Riattiva l&apos;audio dal silenzio</translation>
    </message>
    <message>
        <source>Fonts</source>
        <comment>Font context sub-menu item</comment>
        <translation>Tipi di caratteri</translation>
    </message>
    <message>
        <source>Underline</source>
        <comment>Underline context menu item</comment>
        <translation>Sottolineato</translation>
    </message>
    <message>
        <source>Reload</source>
        <comment>Reload context menu item</comment>
        <translation>Ricarica</translation>
    </message>
    <message>
        <source>Move the cursor to the start of the block</source>
        <translation>Sposta il cursore all&apos;inizio del blocco</translation>
    </message>
    <message>
        <source>Ignore</source>
        <comment>Ignore Spelling context menu item</comment>
        <translation>Ignora</translation>
    </message>
    <message>
        <source>Paste</source>
        <comment>Paste context menu item</comment>
        <translation>Incolla</translation>
    </message>
    <message>
        <source>Go Forward</source>
        <comment>Forward context menu item</comment>
        <translation>Vai al successivo</translation>
    </message>
    <message>
        <source>Slider</source>
        <comment>Media controller element</comment>
        <translation>Interruttore scorrevole</translation>
    </message>
    <message>
        <source>Pause Button</source>
        <comment>Media controller element</comment>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Outline</source>
        <comment>Outline context menu item</comment>
        <translation>Cornice</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>In basso</translation>
    </message>
    <message>
        <source>Copy</source>
        <comment>Copy context menu item</comment>
        <translation>Copia</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Centra</translation>
    </message>
    <message>
        <source>Indent</source>
        <translation>Rientra</translation>
    </message>
    <message>
        <source>%1 minutes %2 seconds</source>
        <comment>Media time description</comment>
        <translation>%1 minuti %2 secondi</translation>
    </message>
    <message>
        <source>Move the cursor to the end of the line</source>
        <translation>Sposta il cursore alla fine del blocco</translation>
    </message>
    <message>
        <source>Save Image</source>
        <comment>Download Image context menu item</comment>
        <translation>Salva immagine</translation>
    </message>
    <message>
        <source>Move the cursor to the start of the line</source>
        <translation>Sposta il cursore alla fine della linea</translation>
    </message>
    <message>
        <source>Copy Link</source>
        <comment>Copy Link context menu item</comment>
        <translation>Copia collegamento</translation>
    </message>
    <message>
        <source>Status Display</source>
        <comment>Media controller element</comment>
        <translation>Mostra  stato</translation>
    </message>
    <message>
        <source>The script on this page appears to have a problem. Do you want to stop the script?</source>
        <translation>Lo script di questa pagina sembra avere alcuni problemi. Desideri fermarlo?</translation>
    </message>
    <message>
        <source>JavaScript Confirm - %1</source>
        <translation>Conferma JavaScript - %1</translation>
    </message>
    <message>
        <source>Insert a new line</source>
        <translation>Inserisci una nuova riga</translation>
    </message>
    <message>
        <source>Audio Element</source>
        <comment>Media controller element</comment>
        <translation>Elemento audio</translation>
    </message>
    <message>
        <source>No file selected</source>
        <comment>text to display in file button used in HTML forms when no file is selected</comment>
        <translation>Nessun file selezionato</translation>
    </message>
    <message>
        <source>Return streaming movie to real-time</source>
        <comment>Media controller element</comment>
        <translation>Passa dal filmato streaming a quello in tempo reale</translation>
    </message>
    <message>
        <source>Check Spelling</source>
        <comment>Check spelling context menu item</comment>
        <translation>Controllo ortografico</translation>
    </message>
    <message>
        <source>Return to Real-time Button</source>
        <comment>Media controller element</comment>
        <translation>Passa al filmato in tempo reale</translation>
    </message>
    <message>
        <source>Web Inspector - %2</source>
        <translation>Ispettore web - %2</translation>
    </message>
    <message>
        <source>Page up</source>
        <translation>Pagina sù</translation>
    </message>
    <message>
        <source>Rewind movie</source>
        <comment>Media controller element</comment>
        <translation>Riavvolgi video</translation>
    </message>
    <message>
        <source>No recent searches</source>
        <comment>Label for only item in menu that appears when clicking on the search field image, when no searches have been performed</comment>
        <translation>Nessuna ricerca recente</translation>
    </message>
    <message>
        <source>Paste and Match Style</source>
        <translation>Incolla e corrispondi lo stile</translation>
    </message>
    <message>
        <source>Look Up In Dictionary</source>
        <comment>Look Up in Dictionary context menu item</comment>
        <translation>Cerca nel dizionario</translation>
    </message>
    <message>
        <source>Outdent</source>
        <translation>Riduci rientranza</translation>
    </message>
    <message>
        <source>Inspect</source>
        <comment>Inspect Element context menu item</comment>
        <translation>Ispeziona</translation>
    </message>
    <message>
        <source>Play movie in full-screen mode</source>
        <comment>Media controller element</comment>
        <translation>Riproduci filmato a schermo intero</translation>
    </message>
    <message>
        <source>Ignore</source>
        <comment>Ignore Grammar context menu item</comment>
        <translation>Ignora</translation>
    </message>
    <message>
        <source>Check Grammar With Spelling</source>
        <comment>Check grammar with spelling context menu item</comment>
        <translation>Controlla la grammatica assieme all&apos;ortografia</translation>
    </message>
    <message>
        <source>Insert Bulleted List</source>
        <translation>Inserisci elenchi puntati</translation>
    </message>
    <message>
        <source>JavaScript Problem - %1</source>
        <translation>Problema di JavaScript - %1</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Pagina destra</translation>
    </message>
    <message>
        <source>Move the cursor to the start of the document</source>
        <translation>Sposta il cursore all&apos;inizio del documento</translation>
    </message>
    <message>
        <source>Remaining movie time</source>
        <comment>Media controller element</comment>
        <translation>Durata restante del filmato</translation>
    </message>
    <message>
        <source>Move the cursor to the next character</source>
        <translation>Sposta il cursore all&apos;inizio del carattere</translation>
    </message>
    <message>
        <source>JavaScript Prompt - %1</source>
        <translation>Prompt di JavaScript - %1</translation>
    </message>
    <message>
        <source>Submit</source>
        <comment>default label for Submit buttons in forms on web pages</comment>
        <translation>Sottoscrivi</translation>
    </message>
    <message>
        <source>Show Spelling and Grammar</source>
        <comment>menu item title</comment>
        <translation>Mostra ortografia e grammatica</translation>
    </message>
    <message>
        <source>Default</source>
        <comment>Default writing direction context menu item</comment>
        <translation>Preimpostato</translation>
    </message>
    <message>
        <source>Select to the previous line</source>
        <translation>Seleziona la riga precedente</translation>
    </message>
    <message>
        <source>Select to the previous word</source>
        <translation>Seleziona la parola precedente</translation>
    </message>
    <message>
        <source>Current movie time</source>
        <comment>Media controller element</comment>
        <translation>Durata corrente del filmato</translation>
    </message>
    <message>
        <source>Redirection limit reached</source>
        <translation>Limite di reindirizzamento raggiunto</translation>
    </message>
    <message>
        <source>Check Spelling While Typing</source>
        <comment>Check spelling while typing context menu item</comment>
        <translation>Controlla l&apos;ortografia durante la digitazione</translation>
    </message>
    <message>
        <source>Clear recent searches</source>
        <comment>menu item in Recent Searches menu that empties menu&apos;s contents</comment>
        <translation>Elimina ricerche recenti</translation>
    </message>
    <message>
        <source>Select to the next character</source>
        <translation>Seleziona all&apos;inizio del carattere</translation>
    </message>
    <message>
        <source>Slider Thumb</source>
        <comment>Media controller element</comment>
        <translation>Interruttore scorrevole miniature</translation>
    </message>
    <message>
        <source>%1 seconds</source>
        <comment>Media time description</comment>
        <translation>%1 secondi</translation>
    </message>
    <message>
        <source>Text Direction</source>
        <comment>Text direction context sub-menu item</comment>
        <translation>Direzione del testo</translation>
    </message>
    <message>
        <source>Delete to the end of the word</source>
        <translation>Elimina alla fine della parola</translation>
    </message>
    <message>
        <source>Select to the end of the line</source>
        <translation>Seleziona alla fine della linea</translation>
    </message>
    <message>
        <source>Submit</source>
        <comment>Submit (input element) alt text for &lt;input&gt; elements with no alt, title, or value</comment>
        <translation>Sottoscrivi</translation>
    </message>
    <message>
        <source>Loading...</source>
        <comment>Media controller status message when the media is loading</comment>
        <translation>Caricamento...</translation>
    </message>
    <message>
        <source>Save Link...</source>
        <comment>Download Linked File context menu item</comment>
        <translation>Salva collegamento...</translation>
    </message>
    <message>
        <source>Open Link</source>
        <comment>Open Link context menu item</comment>
        <translation>Apri collegamento</translation>
    </message>
    <message>
        <source>Scroll up</source>
        <translation>Scorri verso l&apos;alto</translation>
    </message>
    <message>
        <source>Spelling</source>
        <comment>Spelling and Grammar context sub-menu item</comment>
        <translation>Ortografia</translation>
    </message>
    <message>
        <source>Live Broadcast</source>
        <comment>Media controller status message when watching a live broadcast</comment>
        <translation>Trasmissione in diretta</translation>
    </message>
    <message>
        <source>Video Element</source>
        <comment>Media controller element</comment>
        <translation>Elemento video</translation>
    </message>
    <message>
        <source>Subscript</source>
        <translation>Sottoscritto</translation>
    </message>
    <message>
        <source>Superscript</source>
        <translation>Soprascritto</translation>
    </message>
    <message>
        <source>Bold</source>
        <comment>Bold context menu item</comment>
        <translation>Grassetto</translation>
    </message>
    <message>
        <source>Hide Spelling and Grammar</source>
        <comment>menu item title</comment>
        <translation>Nascondi ortografia e granmmatica</translation>
    </message>
    <message>
        <source>Copy Image</source>
        <comment>Copy Link context menu item</comment>
        <translation>Copia immagine</translation>
    </message>
    <message>
        <source>Select to the start of the document</source>
        <translation>Seleziona all&apos;inizio del documento</translation>
    </message>
    <message>
        <source>Add To Dictionary</source>
        <comment>Learn Spelling context menu item</comment>
        <translation>Aggiungi nel dizionario</translation>
    </message>
    <message>
        <source>Remaining Time</source>
        <comment>Media controller element</comment>
        <translation>Tempo rimanente</translation>
    </message>
    <message>
        <source>Seek quickly forward</source>
        <comment>Media controller element</comment>
        <translation>Avanza velocemente nella ricerca</translation>
    </message>
    <message>
        <source>%1 hours %2 minutes %3 seconds</source>
        <comment>Media time description</comment>
        <translation>%1 ore %2 minuti %3 secondi</translation>
    </message>
    <message>
        <source>Seek quickly back</source>
        <comment>Media controller element</comment>
        <translation>Arretra velocemente nella ricerca</translation>
    </message>
    <message>
        <source>Cut</source>
        <comment>Cut context menu item</comment>
        <translation>Taglia</translation>
    </message>
    <message>
        <source>Move the cursor to the previous character</source>
        <translation>Sposta il cursore al carattere precedente</translation>
    </message>
    <message>
        <source>Video element playback controls and status display</source>
        <comment>Media controller element</comment>
        <translation>Visualizza lo stato e i controlli per la riproduzione dei video</translation>
    </message>
    <message>
        <source>Insert Numbered List</source>
        <translation>Inserisci elenco numerato</translation>
    </message>
    <message>
        <source>Select to the end of the document</source>
        <translation>Seleziona alla fine del documento</translation>
    </message>
    <message>
        <source>Select to the end of the block</source>
        <translation>Seleziona alla fine del blocco</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
    <message>
        <source>Movie time scrubber</source>
        <comment>Media controller element</comment>
        <translation>Azzera durata del filmato</translation>
    </message>
    <message>
        <source>Scroll right</source>
        <translation>Scorri verso destra</translation>
    </message>
    <message>
        <source>Bad HTTP request</source>
        <translation>Cattiva richiesta HTTP</translation>
    </message>
    <message>
        <source>Rewind Button</source>
        <comment>Media controller element</comment>
        <translation>Riavvolgi</translation>
    </message>
    <message>
        <source>Indefinite time</source>
        <comment>Media time description</comment>
        <translation>Tempo indefinito</translation>
    </message>
    <message>
        <source>Open Frame</source>
        <comment>Open Frame in New Window context menu item</comment>
        <translation>Apri fotogramma</translation>
    </message>
    <message>
        <source>Current movie status</source>
        <comment>Media controller element</comment>
        <translation>Stato corrente del filmato</translation>
    </message>
    <message>
        <source>%1 days %2 hours %3 minutes %4 seconds</source>
        <comment>Media time description</comment>
        <translation>%1 giorni %2 ore %3 minuti %4 secondi</translation>
    </message>
    <message>
        <source>Move the cursor to the previous word</source>
        <translation>Sposta il cursore alla parola precedente</translation>
    </message>
    <message>
        <source>Move the cursor to the previous line</source>
        <translation>Sposta il cursore alla linea precedente</translation>
    </message>
    <message>
        <source>Seek Back Button</source>
        <comment>Media controller element</comment>
        <translation>Arretra  nella ricerca</translation>
    </message>
    <message numerus="yes">
        <source>%n file(s)</source>
        <translation>
            <numerusform>%n fichier</numerusform>
            <numerusform>%n file</numerusform>
        </translation>
    </message>
    <message>
        <source>%1 (%2x%3 pixels)</source>
        <comment>Title string for images</comment>
        <translation>%1 (%2x%3 pixels)</translation>
    </message>
    <message>
        <source>Left edge</source>
        <translation>A sinistra</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Pagina giù</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Pagina sinistra</translation>
    </message>
    <message>
        <source>Missing Plug-in</source>
        <translation>Plug-in mancante</translation>
    </message>
    <message>
        <source>Reset</source>
        <comment>default label for Reset buttons in forms on web pages</comment>
        <translation>Azzera</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>Allinea a sinistra</translation>
    </message>
    <message>
        <source>Select to the previous character</source>
        <translation>Seleziona il carattere precedente</translation>
    </message>
    <message>
        <source>Mute audio tracks</source>
        <comment>Media controller element</comment>
        <translation>Silenzia le tracce</translation>
    </message>
    <message>
        <source>Audio element playback controls and status display</source>
        <comment>Media controller element</comment>
        <translation>Visualizza lo stato e i controlli per la riproduzione dell&apos;audio</translation>
    </message>
    <message>
        <source>Begin playback</source>
        <comment>Media controller element</comment>
        <translation>Inizia la riproduzione</translation>
    </message>
    <message>
        <source>Choose File</source>
        <comment>title for file button used in HTML forms</comment>
        <translation>Seleziona file</translation>
    </message>
    <message>
        <source>Pause playback</source>
        <comment>Media controller element</comment>
        <translation>Pausa</translation>
    </message>
    <message>
        <source>Open Image</source>
        <comment>Open Image in New Window context menu item</comment>
        <translation>Apri immagine</translation>
    </message>
    <message>
        <source>Mute Button</source>
        <comment>Media controller element</comment>
        <translation>Silenzia</translation>
    </message>
    <message>
        <source>Play Button</source>
        <comment>Media controller element</comment>
        <translation>Riproduci</translation>
    </message>
    <message>
        <source>Right edge</source>
        <translation>A destra</translation>
    </message>
    <message>
        <source>Elapsed Time</source>
        <comment>Media controller element</comment>
        <translation>Tempo trascorso</translation>
    </message>
    <message>
        <source>Move the cursor to the end of the document</source>
        <translation>Sposta il cursore alla fine del documento</translation>
    </message>
    <message>
        <source>Remove formatting</source>
        <translation>Rimuovi formattazione</translation>
    </message>
    <message>
        <source>Open in New Window</source>
        <comment>Open in New Window context menu item</comment>
        <translation>Apri in una nuova finestra</translation>
    </message>
    <message>
        <source>Select to the next word</source>
        <translation>Seleziona fino alla parola successiva</translation>
    </message>
    <message>
        <source>Select to the next line</source>
        <translation>Seleziona fino alla riga successiva</translation>
    </message>
    <message>
        <source>Movie time scrubber thumb</source>
        <comment>Media controller element</comment>
        <translation>Azzera miniatura durata del filmato</translation>
    </message>
    <message>
        <source>Italic</source>
        <comment>Italic context menu item</comment>
        <translation>Corsivo</translation>
    </message>
</context>
<context>
    <name>QFile</name>
    <message>
        <source>Cannot remove source file</source>
        <translation>Impossibile rimuovere il file sorgente</translation>
    </message>
    <message>
        <source>Cannot create %1 for output</source>
        <translation>Impossibile creare %1 per la scrittura</translation>
    </message>
    <message>
        <source>Failure to write block</source>
        <translation>Impossibile scrivere un blocco</translation>
    </message>
    <message>
        <source>Cannot open %1 for input</source>
        <translation>Impossibile aprire %1 per la lettura</translation>
    </message>
    <message>
        <source>Destination file exists</source>
        <translation>Il file di destinazione esiste già</translation>
    </message>
    <message>
        <source>Cannot open for output</source>
        <translation>Impossibile aprire il file per la scrittura</translation>
    </message>
    <message>
        <source>Will not rename sequential file using block copy</source>
        <translation>I file sequenziali non verreanno rinominati utilizzando la copia del blocco</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <source>File</source>
        <translation>File</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>&amp;Open</source>
        <translation>&amp;Apri</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation>&amp;Salva</translation>
    </message>
    <message>
        <source>Drive</source>
        <translation>Unità</translation>
    </message>
    <message>
        <source>Show </source>
        <translation>Mostra</translation>
    </message>
    <message>
        <source>&apos;%1&apos; is write protected.
Do you want to delete it anyway?</source>
        <translation>&apos;%1&apos; è protetto in scrittura.
Eliminare il file comunque?</translation>
    </message>
    <message>
        <source>File &amp;name:</source>
        <translation>&amp;Nome file:</translation>
    </message>
    <message>
        <source>Alias</source>
        <comment>Mac OS X Finder</comment>
        <translation>Alias</translation>
    </message>
    <message>
        <source>File Folder</source>
        <comment>Match Windows Explorer</comment>
        <translation>Cartella file</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Nuova cartella</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <comment>All other platforms</comment>
        <translation>Scorciatoia</translation>
    </message>
    <message>
        <source>Parent Directory</source>
        <translation>Cartella superiore</translation>
    </message>
    <message>
        <source>&amp;New Folder</source>
        <translation>&amp;Nuova cartella</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Computer</translation>
    </message>
    <message>
        <source>Look in:</source>
        <translation>Cerca in:</translation>
    </message>
    <message>
        <source>Create a New Folder</source>
        <translation>Crea nuova cartella</translation>
    </message>
    <message>
        <source>Files of type:</source>
        <translation>Tipi di file:</translation>
    </message>
    <message>
        <source>Find Directory</source>
        <translation>Cerca nella cartella</translation>
    </message>
    <message>
        <source>Show &amp;hidden files</source>
        <translation>Mostra file &amp;nascosti</translation>
    </message>
    <message>
        <source>Are sure you want to delete &apos;%1&apos;?</source>
        <translation>Sei sicuro di volere eliminare &apos;%1&apos; ?</translation>
    </message>
    <message>
        <source>Save As</source>
        <translation>Salva come</translation>
    </message>
    <message>
        <source>%1
Directory not found.
Please verify the correct directory name was given.</source>
        <translation>%1
Cartella non trovata.
Verificare il nome della cartella che sia corretto.</translation>
    </message>
    <message>
        <source>List View</source>
        <translation>Elenco</translation>
    </message>
    <message>
        <source>&amp;Choose</source>
        <translation>&amp;Seleziona</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Elimina</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Tutti i file (*)</translation>
    </message>
    <message>
        <source>Directories</source>
        <translation>Cartelle</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Tutti i file (*.*)</translation>
    </message>
    <message>
        <source>&amp;Rename</source>
        <translation>&amp;Rinomina</translation>
    </message>
    <message>
        <source>Could not delete directory.</source>
        <translation>Impossibile eliminare la cartella.</translation>
    </message>
    <message>
        <source>Directory:</source>
        <translation>Cartella:</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Sconosciuto</translation>
    </message>
    <message>
        <source>%1 already exists.
Do you want to replace it?</source>
        <translation>Il file %1 esiste già.
Sostituire il file?</translation>
    </message>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation>Cartella</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Successivo</translation>
    </message>
    <message>
        <source>Go forward</source>
        <translation>Vai al successivo</translation>
    </message>
    <message>
        <source>Go to the parent directory</source>
        <translation>Vai al livello superiore della cartella</translation>
    </message>
    <message>
        <source>Recent Places</source>
        <translation>Risorse recenti</translation>
    </message>
    <message>
        <source>Go back</source>
        <translation>Torna indietro</translation>
    </message>
    <message>
        <source>Change to detail view mode</source>
        <translation>Passa alla visualizzazione come dettagli</translation>
    </message>
    <message>
        <source>Create New Folder</source>
        <translation>Crea nuoba cartella</translation>
    </message>
    <message>
        <source>Detail View</source>
        <translation>Dettagli</translation>
    </message>
    <message>
        <source>%1
File not found.
Please verify the correct file name was given.</source>
        <translation>%1
File non trovato.
Verificare il nome del file che sia corretto.</translation>
    </message>
    <message>
        <source>Change to list view mode</source>
        <translation>Passa alla visualizzazione come elenco</translation>
    </message>
</context>
<context>
    <name>Q3TextEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Taglia</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Cop&amp;ia</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Ripeti</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Annulla</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Pulisci</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Incolla</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
</context>
<context>
    <name>QLineEdit</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Taglia</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Cop&amp;ia</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Ripeti</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Annulla</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Incolla</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
</context>
<context>
    <name>QTextControl</name>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Taglia</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Cop&amp;ia</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>&amp;Ripeti</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Annulla</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>&amp;Incolla</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Seleziona tutto</translation>
    </message>
    <message>
        <source>Copy &amp;Link Location</source>
        <translation>Copia &amp;collegamento dell&apos;indirizzo di destinazione</translation>
    </message>
</context>
<context>
    <name>QDockWidget</name>
    <message>
        <source>Dock</source>
        <translation>Aggancia</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Float</source>
        <translation>Mobile</translation>
    </message>
</context>
<context>
    <name>QDialog</name>
    <message>
        <source>Done</source>
        <translation>Fine</translation>
    </message>
    <message>
        <source>What&apos;s This?</source>
        <translation>Che cos&apos;è?</translation>
    </message>
</context>
<context>
    <name>QWizard</name>
    <message>
        <source>Done</source>
        <translation>Operazione completata</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Guida</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Guida</translation>
    </message>
    <message>
        <source>&amp;Next</source>
        <translation>&amp;Successivo</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Commit</source>
        <translation>Deposita</translation>
    </message>
    <message>
        <source>Continue</source>
        <translation>Continua</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Fine</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Avanti &gt;</translation>
    </message>
    <message>
        <source>Go Back</source>
        <translation>Torna indietro</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Indietro</translation>
    </message>
</context>
<context>
    <name>QPageSetupWidget</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>Marginre inferiore</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>Foglio</translation>
    </message>
    <message>
        <source>Paper source:</source>
        <translation>Alimentazione:</translation>
    </message>
    <message>
        <source>Centimeters (cm)</source>
        <translation>Centimetri (cm)</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>Margine destro</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Margini</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Orizzontale</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Larghezza:</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Orientamento</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Verticale</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>Marginre superiore</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>Marginre sinistro</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Dimensioni pagina:</translation>
    </message>
    <message>
        <source>Reverse portrait</source>
        <translation>Verticale capovolto</translation>
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation>Millimetri (mm)</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>Punti (pt)</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>Pollici (in)</translation>
    </message>
    <message>
        <source>Reverse landscape</source>
        <translation>Orizzontale capovolto</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Altezza: </translation>
    </message>
</context>
<context>
    <name>QPrintPropertiesWidget</name>
    <message>
        <source>Form</source>
        <translation>Modulo</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Pagina</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Avanzato</translation>
    </message>
</context>
<context>
    <name>QMdiSubWindow</name>
    <message>
        <source>Help</source>
        <translation>Guida</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Sposta</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Ridimensiona</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Riduci a icona</translation>
    </message>
    <message>
        <source>Shade</source>
        <translation>Arrotola</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>&amp;Sempre in primo piano</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <source>- [%1]</source>
        <translation>- [%1]</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Ripristina</translation>
    </message>
    <message>
        <source>Restore</source>
        <translation>Ripristina</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Ingrandisci</translation>
    </message>
    <message>
        <source>Unshade</source>
        <translation>Srotola</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>&amp;Riduci a icona</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>&amp;Ingrandisci</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Ripristina in basso</translation>
    </message>
</context>
<context>
    <name>QDoubleSpinBox</name>
    <message>
        <source>Less</source>
        <translation>Meno</translation>
    </message>
    <message>
        <source>More</source>
        <translation>Più</translation>
    </message>
</context>
<context>
    <name>QSpinBox</name>
    <message>
        <source>Less</source>
        <translation>Meno</translation>
    </message>
    <message>
        <source>More</source>
        <translation>Più</translation>
    </message>
</context>
<context>
    <name>QDirModel</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation>Tipologia</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Data di modifica</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Dimensioni</translation>
    </message>
    <message>
        <source>%1 GB</source>
        <translation>%1 GB</translation>
    </message>
    <message>
        <source>%1 KB</source>
        <translation>%1 KB</translation>
    </message>
    <message>
        <source>%1 MB</source>
        <translation>%1 MB</translation>
    </message>
    <message>
        <source>%1 TB</source>
        <translation>%1 TB</translation>
    </message>
    <message>
        <source>&lt;b&gt;The name &quot;%1&quot; can not be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuations marks.</source>
        <translation>&lt;b&gt;Il nome &quot;%1&quot; non può essere usato.&lt;/b&gt;&lt;p&gt;Provare ad utilizzare un altro nome con meno caratteri o senza simboli di punteggiatura.</translation>
    </message>
    <message>
        <source>%1 bytes</source>
        <translation>%1 byte</translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation>Computer</translation>
    </message>
    <message>
        <source>Computer</source>
        <translation>Computer</translation>
    </message>
    <message>
        <source>Invalid filename</source>
        <translation>Nome file non valido</translation>
    </message>
    <message>
        <source>%1 byte(s)</source>
        <translation>%1 byte</translation>
    </message>
    <message>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation>Tipologia</translation>
    </message>
    <message>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation>Tipo</translation>
    </message>
    <message>
        <source>Date Modified</source>
        <translation>Data di modifica</translation>
    </message>
</context>
<context>
    <name>QPPDOptionsModel</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
</context>
<context>
    <name>QScriptDebuggerLocalsModel</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Valore</translation>
    </message>
</context>
<context>
    <name>QScriptDebuggerStackModel</name>
    <message>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <source>Level</source>
        <translation>Livello</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Percorso</translation>
    </message>
</context>
<context>
    <name>QScriptDebuggerCodeFinderWidget</name>
    <message>
        <source>Next</source>
        <translation>Successivo</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Whole words</source>
        <translation>Parole intere</translation>
    </message>
    <message>
        <source>Previous</source>
        <translation>Precedente</translation>
    </message>
    <message>
        <source>&lt;img src=&quot;:/qt/scripttools/debugging/images/wrap.png&quot;&gt;&amp;nbsp;Search wrapped</source>
        <translation>&lt;img src=&quot;:/qt/scripttools/debugging/images/wrap.png&quot;&gt;&amp;nbsp;Ricerca ripresa</translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation>MAIUSCOLE/minuscole</translation>
    </message>
</context>
<context>
    <name>QComboBox</name>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>True</source>
        <translation>Vero</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
</context>
<context>
    <name>QMenu</name>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Execute</source>
        <translation>Esegui</translation>
    </message>
</context>
<context>
    <name>QPushButton</name>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
</context>
<context>
    <name>QToolButton</name>
    <message>
        <source>Open</source>
        <translation>Apri</translation>
    </message>
    <message>
        <source>Press</source>
        <translation>Premi</translation>
    </message>
</context>
<context>
    <name>QUndoGroup</name>
    <message>
        <source>Redo</source>
        <translation>Ripeti</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>QUndoStack</name>
    <message>
        <source>Redo</source>
        <translation>Ripeti</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>Q3DataTable</name>
    <message>
        <source>True</source>
        <translation>Vero</translation>
    </message>
    <message>
        <source>False</source>
        <translation>Falso</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Inserisci</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Aggiorna</translation>
    </message>
</context>
<context>
    <name>QScriptEngineDebugger</name>
    <message>
        <source>View</source>
        <translation>Visualizza</translation>
    </message>
    <message>
        <source>Stack</source>
        <translation>Pila</translation>
    </message>
    <message>
        <source>Debug Output</source>
        <translation>Uscita di debug</translation>
    </message>
    <message>
        <source>Breakpoints</source>
        <translation>Punti di interruzione</translation>
    </message>
    <message>
        <source>Qt Script Debugger</source>
        <translation>Debugger di script Qt</translation>
    </message>
    <message>
        <source>Locals</source>
        <translation>Locali</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Error Log</source>
        <translation>Registro degli errori</translation>
    </message>
    <message>
        <source>Console</source>
        <translation>Console</translation>
    </message>
    <message>
        <source>Loaded Scripts</source>
        <translation>Script caricati</translation>
    </message>
</context>
<context>
    <name>QSslSocket</name>
    <message>
        <source>Error creating SSL session: %1</source>
        <translation>Errore nella creazione della sessione SSL: %1</translation>
    </message>
    <message>
        <source>Error creating SSL session, %1</source>
        <translation>Errore nella creazione della sessione SSL, %1</translation>
    </message>
    <message>
        <source>The certificate&apos;s notAfter field contains an invalid time</source>
        <translation>Il campo notAfter del certificato contiene un&apos;ora non valida</translation>
    </message>
    <message>
        <source>No error</source>
        <translation>Nessun errorre</translation>
    </message>
    <message>
        <source>Cannot provide a certificate with no key, %1</source>
        <translation>Impossibile fornire un certificato senza chiave, %1</translation>
    </message>
    <message>
        <source>Unable to write data: %1</source>
        <translation>Impossibile scrivere i dati: %1</translation>
    </message>
    <message>
        <source>The basicConstraints path length parameter has been exceeded</source>
        <translation>Il parametro di lunghezza di percorso basicConstraints è stato superato</translation>
    </message>
    <message>
        <source>The certificate has expired</source>
        <translation>Il certificato è scaduto</translation>
    </message>
    <message>
        <source>Error during SSL handshake: %1</source>
        <translation>Errore nell&apos;inizializzazione SSL: %1</translation>
    </message>
    <message>
        <source>Error loading local certificate, %1</source>
        <translation>Errore nel caricamento del certificato locale, %1</translation>
    </message>
    <message>
        <source>The certificate is self-signed, and untrusted</source>
        <translation>Il certificato è firmato da sé e non affidabile</translation>
    </message>
    <message>
        <source>The peer did not present any certificate</source>
        <translation>La controparte non ha presentato nessun certificato</translation>
    </message>
    <message>
        <source>The root CA certificate is marked to reject the specified purpose</source>
        <translation>Il certificato radice dell&apos;autorità di certificazione è segnato per rifiutare lo scopo specifico</translation>
    </message>
    <message>
        <source>Invalid or empty cipher list (%1)</source>
        <translation>Elenco di cifrari non valido o vuoto (%1)</translation>
    </message>
    <message>
        <source>No certificates could be verified</source>
        <translation>Non è stato possibile verificare nessun certificato</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its issuer name and serial number was present and did not match the authority key identifier of the current certificate</source>
        <translation>Il certificato candidato attuale dell&apos;emittente è stato rifiutato perché erano presenti il nome dell&apos;emittente e il numero di serie, e non corrispondono all&apos;identificativo della chiave di autorità del certificato attuale</translation>
    </message>
    <message>
        <source>The root CA certificate is not trusted for this purpose</source>
        <translation>Il certificato radice dell&apos;autorità di certificazione non è affidabile questo scopo</translation>
    </message>
    <message>
        <source>The host name did not match any of the valid hosts for this certificate</source>
        <translation>Il nome dell&apos;host non coincide con nessuno degli host validi per questo certificato</translation>
    </message>
    <message>
        <source>The root certificate of the certificate chain is self-signed, and untrusted</source>
        <translation>Il certificato radice della catena di certificati è firmato da sé e non affidabile</translation>
    </message>
    <message>
        <source>The certificate signature could not be decrypted</source>
        <translation>Impossibile decifrare la firma del certificato</translation>
    </message>
    <message>
        <source>The supplied certificate is unsuitable for this purpose</source>
        <translation>Il certificato fornito non è adatto per questo scopo</translation>
    </message>
    <message>
        <source>Private key does not certify public key, %1</source>
        <translation>La chiave privata non certifica quella pubblica, %1</translation>
    </message>
    <message>
        <source>Error creating SSL context (%1)</source>
        <translation>Errore nella creazione del contesto SSL (%1)</translation>
    </message>
    <message>
        <source>The issuer certificate could not be found</source>
        <translation>Impossibile trovare il certificato dell&apos;emittente</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>The current candidate issuer certificate was rejected because its subject name did not match the issuer name of the current certificate</source>
        <translation>Il certificato candidato attuale dell&apos;emittente è stato rifiutato perché il nome del suo oggetto non corrisponde al nome dell&apos;emittente del certificato attuale</translation>
    </message>
    <message>
        <source>Error while reading: %1</source>
        <translation>Errore nella lettura: %1</translation>
    </message>
    <message>
        <source>The certificate&apos;s notBefore field contains an invalid time</source>
        <translation>Il campo notBefore del certificato contiene un&apos;ora non valida</translation>
    </message>
    <message>
        <source>Error loading private key, %1</source>
        <translation>Errore nel caricamento della chiave privata, %1</translation>
    </message>
    <message>
        <source>The certificate is not yet valid</source>
        <translation>Il certificato non è ancora valido</translation>
    </message>
    <message>
        <source>The public key in the certificate could not be read</source>
        <translation>Impossibile leggere la chiave pubblica del certificato</translation>
    </message>
    <message>
        <source>One of the CA certificates is invalid</source>
        <translation>Uno dei certificati dell&apos;autorità di certificazione non è valido</translation>
    </message>
    <message>
        <source>The signature of the certificate is invalid</source>
        <translation>La firma del certificato non è valida</translation>
    </message>
    <message>
        <source>The issuer certificate of a locally looked up certificate could not be found</source>
        <translation>Le certificat de l&apos;émetteur d&apos;un certificat converti localement est introuvable</translation>
    </message>
    <message>
        <source>Unable to decrypt data: %1</source>
        <translation>Impossibile decifrare i dati: %1</translation>
    </message>
</context>
<context>
    <name>QLocalSocket</name>
    <message>
        <source>%1: Connection error</source>
        <translation>%1: Errore di connessione</translation>
    </message>
    <message>
        <source>%1: Connection refused</source>
        <translation>%1: Connessione rifiutata</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: errore sconosciuto %2</translation>
    </message>
    <message>
        <source>%1: Socket access error</source>
        <translation>%1: Errore di accesso al socket</translation>
    </message>
    <message>
        <source>%1: Socket resource error</source>
        <translation>%1: Errore di risorsa del socket</translation>
    </message>
    <message>
        <source>%1: The socket operation is not supported</source>
        <translation>%1: L&apos;operazione sul socket non è supportata</translation>
    </message>
    <message>
        <source>%1: Invalid name</source>
        <translation>%1: Nome non valido</translation>
    </message>
    <message>
        <source>%1: Unknown error</source>
        <translation>%1: Errore sconosciuto</translation>
    </message>
    <message>
        <source>%1: Socket operation timed out</source>
        <translation>%1: Operazione sul socket scaduta</translation>
    </message>
    <message>
        <source>%1: Datagram too large</source>
        <translation>%1: Datagramma troppo grande</translation>
    </message>
    <message>
        <source>%1: Remote closed</source>
        <translation>%1: Host remoto chiuso</translation>
    </message>
</context>
<context>
    <name>QOCIResult</name>
    <message>
        <source>Unable to get statement type</source>
        <translation>Impossibile recuperare il tipo di dichiarazione</translation>
    </message>
    <message>
        <source>Unable to alloc statement</source>
        <translation>Impossibile allocare la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to goto next</source>
        <translation>Impossibile passare al successivo</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Impossibile eseguire la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to bind column for batch execute</source>
        <translation>Impossibile collegare la colonna per l&apos;esecuzione in serie</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Impossibile preparare la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to execute batch statement</source>
        <translation>Impossibile eseguire la dichiarazione in serie</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>Impossibile collegare il valore</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAnchors</name>
    <message>
        <source>Cannot anchor item to self.</source>
        <translation>Impossibile ancorare un elemento a sè stesso.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on horizontal anchor.</source>
        <translation>Possibile ciclo ancorato rilevato all&apos;ancoramento orizzontale.</translation>
    </message>
    <message>
        <source>Cannot anchor to a null item.</source>
        <translation>Impossibile ancorare a un elemento nullo.</translation>
    </message>
    <message>
        <source>Cannot specify top, bottom, and vcenter anchors.</source>
        <translation>Impossibile specificare ancore in alto, in basso e al centro verticale.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on centerIn.</source>
        <translation>Possibile ciclo ancorato rilevato al centramento.</translation>
    </message>
    <message>
        <source>Baseline anchor cannot be used in conjunction with top, bottom, or vcenter anchors.</source>
        <translation>L&apos;ancora sulla linea base non è utilizzabile assieme alle ancore in alto, in basso o al centro verticale.</translation>
    </message>
    <message>
        <source>Cannot specify left, right, and hcenter anchors.</source>
        <translation>Impossibile specificare ancore a sinistra, destra e centro orizzontale.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on vertical anchor.</source>
        <translation>Possibile ciclo ancorato rilevato all&apos;ancoramento verticale.</translation>
    </message>
    <message>
        <source>Cannot anchor a horizontal edge to a vertical edge.</source>
        <translation>Impossibile ancorare un bordo orizzontale a uno verticale.</translation>
    </message>
    <message>
        <source>Cannot anchor a vertical edge to a horizontal edge.</source>
        <translation>Impossibile ancorare un bordo verticale a uno orizzontale.</translation>
    </message>
    <message>
        <source>Cannot anchor to an item that isn&apos;t a parent or sibling.</source>
        <translation>Impossibile ancorare a un elemento che non sia padre o di pari livello.</translation>
    </message>
    <message>
        <source>Possible anchor loop detected on fill.</source>
        <translation>Possibile ciclo ancorato rilevato al riempimento.</translation>
    </message>
</context>
<context>
    <name>QDeclarativeCompositeTypeManager</name>
    <message>
        <source>%1 %2</source>
        <translation>%1 %2</translation>
    </message>
    <message>
        <source>Resource %1 unavailable</source>
        <translation>Risors %1 non disponbile</translation>
    </message>
    <message>
        <source>Type %1 unavailable</source>
        <translation>Tipo %1 non disponibile</translation>
    </message>
    <message>
        <source>Namespace %1 cannot be used as a type</source>
        <translation>Lo spazio di nomi %1 non può essere usato come tipo</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AudioEqualizer</name>
    <message>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
</context>
<context>
    <name>QFontDialog</name>
    <message>
        <source>&amp;Font</source>
        <translation>&amp;Tipi di carattere</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Dimensioni</translation>
    </message>
    <message>
        <source>Sample</source>
        <translation>Esempio</translation>
    </message>
    <message>
        <source>Font st&amp;yle</source>
        <translation>&amp;Stile caratteri</translation>
    </message>
    <message>
        <source>Wr&amp;iting System</source>
        <translation>Sistema di sc&amp;rittura</translation>
    </message>
    <message>
        <source>Select Font</source>
        <translation>Seleziona i caratteri</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>Sotto&amp;lineato</translation>
    </message>
    <message>
        <source>Effects</source>
        <translation>Effetti</translation>
    </message>
    <message>
        <source>Stri&amp;keout</source>
        <translation>&amp;Barrato</translation>
    </message>
</context>
<context>
    <name>Q3Wizard</name>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Guida</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Annulla</translation>
    </message>
    <message>
        <source>&amp;Finish</source>
        <translation>&amp;Fine</translation>
    </message>
    <message>
        <source>&amp;Next &gt;</source>
        <translation>&amp;Avanti &gt;</translation>
    </message>
    <message>
        <source>&lt; &amp;Back</source>
        <translation>&lt; &amp;Indietro</translation>
    </message>
</context>
<context>
    <name>QWorkspace</name>
    <message>
        <source>&amp;Move</source>
        <translation>&amp;Sposta</translation>
    </message>
    <message>
        <source>&amp;Size</source>
        <translation>&amp;Ridimensiona</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Riduci a icona</translation>
    </message>
    <message>
        <source>Stay on &amp;Top</source>
        <translation>&amp;Sempre in primo piano</translation>
    </message>
    <message>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <source>%1 - [%2]</source>
        <translation>%1 - [%2]</translation>
    </message>
    <message>
        <source>Sh&amp;ade</source>
        <translation>&amp;Arrotola</translation>
    </message>
    <message>
        <source>&amp;Restore</source>
        <translation>&amp;Ripristina</translation>
    </message>
    <message>
        <source>&amp;Unshade</source>
        <translation>&amp;Srotola</translation>
    </message>
    <message>
        <source>Mi&amp;nimize</source>
        <translation>&amp;Riduci a icona</translation>
    </message>
    <message>
        <source>Ma&amp;ximize</source>
        <translation>&amp;Ingrandisci</translation>
    </message>
    <message>
        <source>Restore Down</source>
        <translation>Ripristina in basso</translation>
    </message>
</context>
<context>
    <name>QColorDialog</name>
    <message>
        <source>&amp;Red:</source>
        <translation>&amp;Rosso:</translation>
    </message>
    <message>
        <source>&amp;Sat:</source>
        <translation>&amp;Saturazione:</translation>
    </message>
    <message>
        <source>&amp;Val:</source>
        <translation>&amp;Valore:</translation>
    </message>
    <message>
        <source>Hu&amp;e:</source>
        <translation>&amp;Tonalità:</translation>
    </message>
    <message>
        <source>Select Color</source>
        <translation>Colore selezionato</translation>
    </message>
    <message>
        <source>&amp;Add to Custom Colors</source>
        <translation>&amp;Aggiungi ai colori personalizzati</translation>
    </message>
    <message>
        <source>Bl&amp;ue:</source>
        <translation>Bl&amp;u : </translation>
    </message>
    <message>
        <source>&amp;Green:</source>
        <translation>&amp;Verde:</translation>
    </message>
    <message>
        <source>&amp;Basic colors</source>
        <translation>Colori di &amp;base</translation>
    </message>
    <message>
        <source>&amp;Custom colors</source>
        <translation>&amp;Colori personalizzati</translation>
    </message>
    <message>
        <source>A&amp;lpha channel:</source>
        <translation>Canale a&amp;lpha :</translation>
    </message>
</context>
<context>
    <name>QNetworkSessionPrivateImpl</name>
    <message>
        <source>Roaming error</source>
        <translation>Errore di roaming</translation>
    </message>
    <message>
        <source>The session was aborted by the user or system.</source>
        <translation>La sessione è stata interrotta dall&apos;utente o dal sistema.</translation>
    </message>
    <message>
        <source>The requested operation is not supported by the system.</source>
        <translation>L&apos;operazione richiesta non è supportata dal sistema.</translation>
    </message>
    <message>
        <source>Session aborted by user or system</source>
        <translation>Sessione interrotta dall&apos;utente o dal sistema</translation>
    </message>
    <message>
        <source>Unidentified Error</source>
        <translation>Errore non identificato</translation>
    </message>
    <message>
        <source>Roaming was aborted or is not possible.</source>
        <translation>Roaming interrotto o impossibile.</translation>
    </message>
    <message>
        <source>The specified configuration cannot be used.</source>
        <translation>La configurazione specificata non può essere usata.</translation>
    </message>
    <message>
        <source>Unknown session error.</source>
        <translation>Errore di sessione sconosciuto.</translation>
    </message>
</context>
<context>
    <name>QSharedMemory</name>
    <message>
        <source>%1: system-imposed size restrictions</source>
        <translation>%1: restrizioni di sistema sulla dimensione</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exists</source>
        <translation>%1: non esiste</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <translation>%1: la chiave è vuota</translation>
    </message>
    <message>
        <source>%1: key error</source>
        <translation>%1 : errore di chiave</translation>
    </message>
    <message>
        <source>%1: create size is less then 0</source>
        <translation>%1: la dimensione creata è inferiore a 0</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: esiste già</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation>%1: errore sconosciuto %2</translation>
    </message>
    <message>
        <source>%1: invalid size</source>
        <translation>%1: dimensione non valida</translation>
    </message>
    <message>
        <source>%1: unable to make key</source>
        <translation>%1: impossibile creare la chiave</translation>
    </message>
    <message>
        <source>%1: unable to set key on lock</source>
        <translation>%1: impossibile impostare la chiave sul blocco</translation>
    </message>
    <message>
        <source>%1: unable to unlock</source>
        <translation>%1: impossibile sbloccare</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: permesso negato</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <translation>%1: ftok non riuscito</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: risorse insufficienti</translation>
    </message>
    <message>
        <source>%1: not attached</source>
        <translation>%1: non allegato</translation>
    </message>
    <message>
        <source>%1: UNIX key file doesn&apos;t exist</source>
        <translation>%1: il file chiave UNIX non esiste</translation>
    </message>
    <message>
        <source>%1: doesn&apos;t exist</source>
        <translation>%1: non esistono</translation>
    </message>
    <message>
        <source>%1: size query failed</source>
        <translation>%1: interrogazione della dimensione non riuscita</translation>
    </message>
    <message>
        <source>%1: unable to lock</source>
        <translation>%1: impossibile bloccare</translation>
    </message>
</context>
<context>
    <name>QXmlStream</name>
    <message>
        <source>Reference to unparsed entity &apos;%1&apos;.</source>
        <translation>Riferimento all&apos;entità &apos;%1&apos; non analizzata.</translation>
    </message>
    <message>
        <source>Unexpected character &apos;%1&apos; in public id literal.</source>
        <translation>Carattere inatteso &quot;%1&quot; in letterale identificativo pubblico.</translation>
    </message>
    <message>
        <source>Illegal namespace declaration.</source>
        <translation>Dichiarazione di spazio di nomi non consentita.</translation>
    </message>
    <message>
        <source>Invalid XML character.</source>
        <translation>Carattere XML non valido.</translation>
    </message>
    <message>
        <source>Expected character data.</source>
        <translation>Erano attesi dati di caratteri.</translation>
    </message>
    <message>
        <source>Standalone accepts only yes or no.</source>
        <translation>&quot;Standalone&quot; accetta solo &quot;yes&quot; o &quot;no&quot;.</translation>
    </message>
    <message>
        <source>Invalid XML version string.</source>
        <translation>Stringa di versione XML non valida.</translation>
    </message>
    <message>
        <source>Invalid processing instruction name.</source>
        <translation>Nome d&apos;istruzione non valido.</translation>
    </message>
    <message>
        <source>Namespace prefix &apos;%1&apos; not declared</source>
        <translation>Prefisso &quot;%1&quot; dello spazio di nomi non dichiarato</translation>
    </message>
    <message>
        <source>Entity &apos;%1&apos; not declared.</source>
        <translation>Entità &apos;%1&apos; non dichiarata.</translation>
    </message>
    <message>
        <source>%1 is an invalid processing instruction name.</source>
        <translation>%1 non è un&apos;istruzione di processo valida.</translation>
    </message>
    <message>
        <source>The standalone pseudo attribute must appear after the encoding.</source>
        <translation>Lo pseudo-attributo &quot;standalone&quot; deve comparire dopo la codifica.</translation>
    </message>
    <message>
        <source>Sequence &apos;]]&gt;&apos; not allowed in content.</source>
        <translation>Sequenza &apos;]]&gt;&apos; non consentita nel contesto.</translation>
    </message>
    <message>
        <source>%1 is an invalid encoding name.</source>
        <translation>%1 non è un nome di codifica valido.</translation>
    </message>
    <message>
        <source>, but got &apos;</source>
        <translation>, invece si è ottenuto &apos;</translation>
    </message>
    <message>
        <source>Start tag expected.</source>
        <translation>Ci si attendeva un marcatore d&apos;inizio.</translation>
    </message>
    <message>
        <source>Invalid character reference.</source>
        <translation>Riferimento di carattere non valido.</translation>
    </message>
    <message>
        <source>Reference to external entity &apos;%1&apos; in attribute value.</source>
        <translation>Riferimento all&apos;entità esterna &apos;%1&apos; nel valore dell&apos;attributo.</translation>
    </message>
    <message>
        <source>Expected </source>
        <translation>Atteso </translation>
    </message>
    <message>
        <source>Invalid document.</source>
        <translation>Documento non valido.</translation>
    </message>
    <message>
        <source>Opening and ending tag mismatch.</source>
        <translation>Il marcatore d&apos;inizio e quello di fine devono corrispondere.</translation>
    </message>
    <message>
        <source>Encountered incorrectly encoded content.</source>
        <translation>Trovato contenuto con codifica non corretta.</translation>
    </message>
    <message>
        <source>Invalid attribute in XML declaration.</source>
        <translation>Attributo non valido nella dichiarazione XML.</translation>
    </message>
    <message>
        <source>Attribute redefined.</source>
        <translation>Attributo ridefinito.</translation>
    </message>
    <message>
        <source>%1 is an invalid PUBLIC identifier.</source>
        <translation>%1 non è un identificatore PUBLIC valido.</translation>
    </message>
    <message>
        <source>Extra content at end of document.</source>
        <translation>Contenuti eccedenti alla fine del documento.</translation>
    </message>
    <message>
        <source>Invalid XML name.</source>
        <translation>Nome XML non valido.</translation>
    </message>
    <message>
        <source>Premature end of document.</source>
        <translation>Chiusura anticipata del documento.</translation>
    </message>
    <message>
        <source>XML declaration not at start of document.</source>
        <translation>La dichiarazione XML deve trovarsi all&apos;inizio del documento.</translation>
    </message>
    <message>
        <source>Recursive entity detected.</source>
        <translation>Entità ricorsiva rilevata.</translation>
    </message>
    <message>
        <source>Unsupported XML version.</source>
        <translation>Versione di XML non supportata.</translation>
    </message>
    <message>
        <source>Unexpected &apos;</source>
        <translation>Inatteso &apos;</translation>
    </message>
    <message>
        <source>Invalid entity value.</source>
        <translation>Valore dell&apos;entità non valido.</translation>
    </message>
    <message>
        <source>Encoding %1 is unsupported</source>
        <translation>La codifica %1 non è supportata</translation>
    </message>
    <message>
        <source>NDATA in parameter entity declaration.</source>
        <translation>NDATA all&apos;interno di una dichiarazione d&apos;entità di parametri.</translation>
    </message>
</context>
<context>
    <name>QProcess</name>
    <message>
        <source>Error writing to process</source>
        <translation>Errore in scrittura sul processo</translation>
    </message>
    <message>
        <source>Resource error (fork failure): %1</source>
        <translation>Errore di risorse (fork non riuscito): %1</translation>
    </message>
    <message>
        <source>Error reading from process</source>
        <translation>Errore in lettura dal processo</translation>
    </message>
    <message>
        <source>Process failed to start: %1</source>
        <translation>Avvio del processo non riuscito: %1</translation>
    </message>
    <message>
        <source>Could not open input redirection for reading</source>
        <translation>Impossibile aprire in lettura la ridirezione dell&apos;ingresso</translation>
    </message>
    <message>
        <source>No program defined</source>
        <translation>Nessun programma definito</translation>
    </message>
    <message>
        <source>Could not open output redirection for writing</source>
        <translation>Impossibile aprire in scrittura la ridirezione dell&apos;uscita</translation>
    </message>
    <message>
        <source>Process operation timed out</source>
        <translation>Tempo scaduto per l&apos;operazione del processo</translation>
    </message>
    <message>
        <source>Process crashed</source>
        <translation>Il processo è andato in crash</translation>
    </message>
</context>
<context>
    <name>QNativeSocketEngine</name>
    <message>
        <source>The proxy type is invalid for this operation</source>
        <translation>Il tipo di proxy non è valido per questa operazione</translation>
    </message>
    <message>
        <source>Network operation timed out</source>
        <translation>Operazione di rete scaduta</translation>
    </message>
    <message>
        <source>The remote host closed the connection</source>
        <translation>L&apos;host remoto ha chiuso la connessione</translation>
    </message>
    <message>
        <source>Invalid socket descriptor</source>
        <translation>Descrittore di socket non valido</translation>
    </message>
    <message>
        <source>Host unreachable</source>
        <translation>Host irraggiungibile</translation>
    </message>
    <message>
        <source>Protocol type not supported</source>
        <translation>Tipo di protocollo non supportato</translation>
    </message>
    <message>
        <source>Datagram was too large to send</source>
        <translation>Datagramma troppo grande per essere inviato</translation>
    </message>
    <message>
        <source>Attempt to use IPv6 socket on a platform with no IPv6 support</source>
        <translation>Tentativo di usare un socket IPv6 su una piattaforma senza supporto IPv6</translation>
    </message>
    <message>
        <source>Unable to receive a message</source>
        <translation>Impossibile ricevere un messaggio</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permesso negato</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Connessione rifiutata</translation>
    </message>
    <message>
        <source>Unable to write</source>
        <translation>Impossibile scrivere</translation>
    </message>
    <message>
        <source>Another socket is already listening on the same port</source>
        <translation>Un altro socket è già in ascolto sulla stessa porta</translation>
    </message>
    <message>
        <source>Unable to send a message</source>
        <translation>Impossibile inviare un messaggio</translation>
    </message>
    <message>
        <source>The bound address is already in use</source>
        <translation>L&apos;indirizzo vincolato è già in uso</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Connessione scaduta</translation>
    </message>
    <message>
        <source>Network error</source>
        <translation>Errore di rete</translation>
    </message>
    <message>
        <source>Unsupported socket operation</source>
        <translation>Operazione sul socket non supportata</translation>
    </message>
    <message>
        <source>Operation on non-socket</source>
        <translation>Operazione su un non-socket</translation>
    </message>
    <message>
        <source>Unable to initialize broadcast socket</source>
        <translation>Impossibile inizializzare socket di broadcast</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Unable to initialize non-blocking socket</source>
        <translation>Impossibile inizializzare socket non bloccante</translation>
    </message>
    <message>
        <source>The address is protected</source>
        <translation>L&apos;indirizzo è protetto</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Rete irraggiungibile</translation>
    </message>
    <message>
        <source>The address is not available</source>
        <translation>L&apos;indirizzo non è disponibile</translation>
    </message>
    <message>
        <source>Out of resources</source>
        <translation>Risorse terminate</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFtpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation>Nessun proxy adatto trovato</translation>
    </message>
    <message>
        <source>Error while downloading %1: %2</source>
        <translation>Errore nello scaricamento di %1: %2</translation>
    </message>
    <message>
        <source>Error while uploading %1: %2</source>
        <translation>Errore nell&apos;invio di %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: is a directory</source>
        <translation>Impossibile aprire %1: è una cartella</translation>
    </message>
    <message>
        <source>Logging in to %1 failed: authentication required</source>
        <translation>Accesso a %1 non riuscito: autenticazione richiesta</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessHttpBackend</name>
    <message>
        <source>No suitable proxy found</source>
        <translation>Nessun proxy adatto trovato</translation>
    </message>
</context>
<context>
    <name>QCheckBox</name>
    <message>
        <source>Check</source>
        <translation>Spunta</translation>
    </message>
    <message>
        <source>Toggle</source>
        <translation>Commuta</translation>
    </message>
    <message>
        <source>Uncheck</source>
        <translation>Togli spunta</translation>
    </message>
</context>
<context>
    <name>QRadioButton</name>
    <message>
        <source>Check</source>
        <translation>Spunta</translation>
    </message>
</context>
<context>
    <name>Q3TitleBar</name>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <source>Minimize</source>
        <translation>Riduci a icona</translation>
    </message>
    <message>
        <source>Displays the name of the window and contains controls to manipulate it</source>
        <translation>Mostra il nome della finestra e contiene i controlli per manipolarla</translation>
    </message>
    <message>
        <source>Makes the window full screen</source>
        <translation>Mostra la finestra a schermo intero</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <source>Maximize</source>
        <translation>Ingrandisci</translation>
    </message>
    <message>
        <source>Contains commands to manipulate the window</source>
        <translation>Contiene i comandi per manipolare la finestra</translation>
    </message>
    <message>
        <source>Restore up</source>
        <translation>Ripristina in alto</translation>
    </message>
    <message>
        <source>Puts a minimized window back to normal</source>
        <translation>Ripristina una finestra minimizzata</translation>
    </message>
    <message>
        <source>Closes the window</source>
        <translation>Chiude la finestra</translation>
    </message>
    <message>
        <source>Puts a maximized window back to normal</source>
        <translation>Ripristina una finestra massimizzata</translation>
    </message>
    <message>
        <source>Moves the window out of the way</source>
        <translation>Toglie di torno la finestra</translation>
    </message>
    <message>
        <source>Restore down</source>
        <translation>Ripristina in basso</translation>
    </message>
</context>
<context>
    <name>QScriptNewBreakpointWidget</name>
    <message>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
</context>
<context>
    <name>Phonon::</name>
    <message>
        <source>Games</source>
        <translation>Giochi</translation>
    </message>
    <message>
        <source>Music</source>
        <translation>Musica</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <source>Communication</source>
        <translation>Comunicazione</translation>
    </message>
    <message>
        <source>Accessibility</source>
        <translation>Accessibilità </translation>
    </message>
    <message>
        <source>Notifications</source>
        <translation>Notifiche</translation>
    </message>
</context>
<context>
    <name>Phonon::VolumeSlider</name>
    <message>
        <source>Muted</source>
        <translation>In silenzio</translation>
    </message>
    <message>
        <source>Volume: %1%</source>
        <translation>Volume : %1%</translation>
    </message>
    <message>
        <source>Use this slider to adjust the volume. The leftmost position is 0%, the rightmost is %1%</source>
        <translation>Utilizzare questo interruttore scorrevole per regolare il volume. La posizione più a sinistra è 0% mentre quella destra è %1%</translation>
    </message>
</context>
<context>
    <name>Q3LocalFs</name>
    <message>
        <source>Could not open
%1</source>
        <translation>Impossibile aprire
%1</translation>
    </message>
    <message>
        <source>Could not remove file or directory
%1</source>
        <translation>Impossibile rimuovere il file o la cartella
%1</translation>
    </message>
    <message>
        <source>Could not create directory
%1</source>
        <translation>Impossibile creare la cartella
%1</translation>
    </message>
    <message>
        <source>Could not read directory
%1</source>
        <translation>Impossibile leggere la cartella
%1</translation>
    </message>
    <message>
        <source>Could not rename
%1
to
%2</source>
        <translation>Impossibile rinominare
%1
a
%2</translation>
    </message>
    <message>
        <source>Could not write
%1</source>
        <translation>Impossibile scrivere
%1</translation>
    </message>
</context>
<context>
    <name>QDial</name>
    <message>
        <source>QDial</source>
        <translation>QDial</translation>
    </message>
    <message>
        <source>SliderHandle</source>
        <translation>Levetta del cursore</translation>
    </message>
    <message>
        <source>SpeedoMeter</source>
        <translation>Tachimetro</translation>
    </message>
</context>
<context>
    <name>QAccessibleButton</name>
    <message>
        <source>Press</source>
        <translation>Premi</translation>
    </message>
</context>
<context>
    <name>QSocks5SocketEngine</name>
    <message>
        <source>Network operation timed out</source>
        <translation>Operazione di rete scaduta</translation>
    </message>
    <message>
        <source>Connection to proxy closed prematurely</source>
        <translation>Connessione al proxy chiusa prematuramente</translation>
    </message>
    <message>
        <source>Proxy authentication failed: %1</source>
        <translation>Autenticazione al proxy non riuscita: %1</translation>
    </message>
    <message>
        <source>Proxy authentication failed</source>
        <translation>Autenticazione al proxy non riuscita</translation>
    </message>
    <message>
        <source>General SOCKSv5 server failure</source>
        <translation>Errore generale del server SOCKSv5</translation>
    </message>
    <message>
        <source>Unknown SOCKSv5 proxy error code 0x%1</source>
        <translation>Codice di errore sconosciuto 0x%1 del proxy SOCKSv5</translation>
    </message>
    <message>
        <source>Connection not allowed by SOCKSv5 server</source>
        <translation>Connessione non consentita dal server SOCKSv5</translation>
    </message>
    <message>
        <source>SOCKSv5 command not supported</source>
        <translation>Comando SOCKSv5 non supportato</translation>
    </message>
    <message>
        <source>Connection to proxy timed out</source>
        <translation>Connessione al proxy scaduta</translation>
    </message>
    <message>
        <source>Proxy host not found</source>
        <translation>Host proxy non trovato</translation>
    </message>
    <message>
        <source>TTL expired</source>
        <translation>TTL scaduto</translation>
    </message>
    <message>
        <source>Address type not supported</source>
        <translation>Tipo di indirizzo non supportato</translation>
    </message>
    <message>
        <source>Connection to proxy refused</source>
        <translation>Connessione al proxy rifiutata</translation>
    </message>
    <message>
        <source>SOCKS version 5 protocol error</source>
        <translation>Errore di protocollo SOCKS versione 5</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF</name>
    <message>
        <source>Could not connect</source>
        <translation>Impossibile connettersi</translation>
    </message>
    <message>
        <source>Access denied</source>
        <translation>Accesso negato</translation>
    </message>
    <message>
        <source>Invalid protocol</source>
        <translation>Protocollo non valido</translation>
    </message>
    <message>
        <source>No error</source>
        <translation>Nessun errorre</translation>
    </message>
    <message>
        <source>Audio Output</source>
        <translation>Uscita audio</translation>
    </message>
    <message>
        <source>Disconnected</source>
        <translation>Disconnesso</translation>
    </message>
    <message>
        <source>Server alert</source>
        <translation>Avviso del server</translation>
    </message>
    <message>
        <source>Out of memory</source>
        <translation>Memoria esaurita</translation>
    </message>
    <message>
        <source>Not supported</source>
        <translation>Non supportato</translation>
    </message>
    <message>
        <source>Invalid URL</source>
        <translation>URL non valido</translation>
    </message>
    <message>
        <source>Video output error</source>
        <translation>Errore nell&apos;uscita video</translation>
    </message>
    <message>
        <source>In use</source>
        <translation>In uso</translation>
    </message>
    <message>
        <source>Insufficient bandwidth</source>
        <translation>Banda insufficiente</translation>
    </message>
    <message>
        <source>Already exists</source>
        <translation>Esiste già </translation>
    </message>
    <message>
        <source>Audio output error</source>
        <translation>Errore nell&apos;uscita audio</translation>
    </message>
    <message>
        <source>Multicast error</source>
        <translation>Errore multicast</translation>
    </message>
    <message>
        <source>Proxy server not supported</source>
        <translation>Server proxy non supportato</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permesso negato</translation>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trovato</translation>
    </message>
    <message>
        <source>Not ready</source>
        <translation>Non pronto</translation>
    </message>
    <message>
        <source>Proxy server error</source>
        <translation>Errore nel server proxy</translation>
    </message>
    <message>
        <source>The audio output device</source>
        <translation>Il dispositivo di uscita dell&apos;audio</translation>
    </message>
    <message>
        <source>Streaming not supported</source>
        <translation>Streaming non supportato</translation>
    </message>
    <message>
        <source>Audio or video components could not be played</source>
        <translation>Impossibile leggere i componenti audio o video</translation>
    </message>
    <message>
        <source>Underflow</source>
        <translation>Scarso flusso</translation>
    </message>
    <message>
        <source>Network communication error</source>
        <translation>Errore di comunicazione di rete</translation>
    </message>
    <message>
        <source>Overflow</source>
        <translation>Sovraccarico</translation>
    </message>
    <message>
        <source>Network unavailable</source>
        <translation>Rete non disponibile</translation>
    </message>
    <message>
        <source>Path not found</source>
        <translation>Percorso non trovato</translation>
    </message>
    <message>
        <source>Decoder error</source>
        <translation>Errore di decodifica</translation>
    </message>
    <message>
        <source>DRM error</source>
        <translation>Errore di DRM</translation>
    </message>
    <message>
        <source>Unknown error (%1)</source>
        <translation>Errore sconosciuto (%1)</translation>
    </message>
</context>
<context>
    <name>QRegExp</name>
    <message>
        <source>invalid category</source>
        <translation>categoria non valida</translation>
    </message>
    <message>
        <source>bad lookahead syntax</source>
        <translation>sintassi errata della ricerca in avanti</translation>
    </message>
    <message>
        <source>no error occurred</source>
        <translation>nessun errore</translation>
    </message>
    <message>
        <source>missing left delim</source>
        <translation>delimitatore sinistro mancante</translation>
    </message>
    <message>
        <source>bad char class syntax</source>
        <translation>sintassi errata di classe di caratteri</translation>
    </message>
    <message>
        <source>disabled feature used</source>
        <translation>è stata usata una funzione disabilitata</translation>
    </message>
    <message>
        <source>invalid octal value</source>
        <translation>valore ottale non valido</translation>
    </message>
    <message>
        <source>bad repetition syntax</source>
        <translation>sintassi errata di ripetizione</translation>
    </message>
    <message>
        <source>met internal limit</source>
        <translation>raggiunto un limite interno</translation>
    </message>
    <message>
        <source>invalid interval</source>
        <translation>intervallo non valido</translation>
    </message>
    <message>
        <source>unexpected end</source>
        <translation>fine inattesa</translation>
    </message>
</context>
<context>
    <name>QWhatsThisAction</name>
    <message>
        <source>What&apos;s This?</source>
        <translation>Che cos&apos;è?</translation>
    </message>
</context>
<context>
    <name>QDeclarativeTextInput</name>
    <message>
        <source>Could not instantiate cursor delegate</source>
        <translation>Impossibile istanziare il delegato del cursore</translation>
    </message>
    <message>
        <source>Could not load cursor delegate</source>
        <translation>Impossibile caricare il delegato del cursore</translation>
    </message>
</context>
<context>
    <name>Q3UrlOperator</name>
    <message>
        <source>The protocol `%1&apos; does not support getting files</source>
        <translation>Il protocollo `%1&apos; non consente la ricezione dei file</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support renaming files or directories</source>
        <translation>Il protocollo `%1&apos; non consente la rinomina dei file o delle cartelle</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support listing directories</source>
        <translation>Il protocollo `%1&apos; non consente l&apos;elencazione delle cartelle</translation>
    </message>
    <message>
        <source>(unknown)</source>
        <translation>(sconosciuto)</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support removing files or directories</source>
        <translation>Il protocollo `%1&apos; non consente la rimozione dei file o delle cartelle</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support putting files</source>
        <translation>Il protocollo `%1&apos; non consente l&apos;invio dei file</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; is not supported</source>
        <translation>Il protocollo `%1&apos; non è supportato</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support copying or moving files or directories</source>
        <translation>Il protocollo `%1&apos; non consente la copia o lo spostamento dei file o delle cartelle</translation>
    </message>
    <message>
        <source>The protocol `%1&apos; does not support creating new directories</source>
        <translation>Il protocollo `%1&apos; non consente la creazione di nuove cartelle</translation>
    </message>
</context>
<context>
    <name>QFtp</name>
    <message>
        <source>Listing directory failed:
%1</source>
        <translation>Elencazione delle cartelle è fallita:
%1</translation>
    </message>
    <message>
        <source>Creating directory failed:
%1</source>
        <translation>Creazione delle cartelle è fallita:
%1</translation>
    </message>
    <message>
        <source>Not connected</source>
        <translation>Non connesso</translation>
    </message>
    <message>
        <source>Connection refused for data connection</source>
        <translation>Connessione rifiutata dalla connessione di dati</translation>
    </message>
    <message>
        <source>Login failed:
%1</source>
        <translation>Autenticazione fallita:
%1</translation>
    </message>
    <message>
        <source>Downloading file failed:
%1</source>
        <translation>Scaricamento del file fallito:
%1</translation>
    </message>
    <message>
        <source>Connected to host</source>
        <translation>Connessione all&apos;host</translation>
    </message>
    <message>
        <source>Connection timed out to host %1</source>
        <translation>Connessione scaduta verso l&apos;host %1</translation>
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation>Connessione all&apos;host %1</translation>
    </message>
    <message>
        <source>Connecting to host failed:
%1</source>
        <translation>Connessione all&apos;host fallita:
%1</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation>Host %1 non trovato</translation>
    </message>
    <message>
        <source>Uploading file failed:
%1</source>
        <translation>Caricamento file sul sever fallito:
%1</translation>
    </message>
    <message>
        <source>Changing directory failed:
%1</source>
        <translation>Modifica della cartella fallita:
%1</translation>
    </message>
    <message>
        <source>Host found</source>
        <translation>Host trovato</translation>
    </message>
    <message>
        <source>Removing directory failed:
%1</source>
        <translation>Rimozione della cartella fallita:
%1</translation>
    </message>
    <message>
        <source>Connection refused to host %1</source>
        <translation>Connessione all&apos;host %1 rifiutata</translation>
    </message>
    <message>
        <source>Connection to %1 closed</source>
        <translation>Connessione a %1 chiusa</translation>
    </message>
    <message>
        <source>Removing file failed:
%1</source>
        <translation>Rimozione file fallita:
%1</translation>
    </message>
    <message>
        <source>Host %1 found</source>
        <translation>Host %1 trovato</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Connessione chiusa</translation>
    </message>
</context>
<context>
    <name>QDeclarativeListModel</name>
    <message>
        <source>set: value is not an object</source>
        <translation>set: il valore non è un oggetto</translation>
    </message>
    <message>
        <source>ListElement: cannot use script for property value</source>
        <translation>ListElement: non può usare uno script come valore di proprietà </translation>
    </message>
    <message>
        <source>ListModel: undefined property &apos;%1&apos;</source>
        <translation>ListModel: proprietà non definita &apos;%1&apos;</translation>
    </message>
    <message>
        <source>ListElement: cannot contain nested elements</source>
        <translation>ListElement: non può contenere elementi annidati</translation>
    </message>
    <message>
        <source>insert: value is not an object</source>
        <translation>insert: il valore non è un oggetto</translation>
    </message>
    <message>
        <source>remove: index %1 out of range</source>
        <translation>remove: l&apos;indice %1 è fuori dai limiti</translation>
    </message>
    <message>
        <source>set: index %1 out of range</source>
        <translation>set: l&apos;indice %1 è fuori dai limiti</translation>
    </message>
    <message>
        <source>append: value is not an object</source>
        <translation>append: il valore non è un oggetto</translation>
    </message>
    <message>
        <source>move: out of range</source>
        <translation>move: fuori dai limiti</translation>
    </message>
    <message>
        <source>insert: index %1 out of range</source>
        <translation>insert: l&apos;indice %1 è fuori dai limiti</translation>
    </message>
    <message>
        <source>ListElement: cannot use reserved &quot;id&quot; property</source>
        <translation>ListElement : non può usare la proprietà  riservata &quot;id&quot;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeEngine</name>
    <message>
        <source>Version mismatch: expected %1, found %2</source>
        <translation>Versione non corrispondente: era attesa %1, trovata %2</translation>
    </message>
    <message>
        <source>executeSql called outside transaction()</source>
        <translation>executeSql chiamato al di fuori di transaction()</translation>
    </message>
    <message>
        <source>Read-only Transaction</source>
        <translation>Transazione di sola lettura</translation>
    </message>
    <message>
        <source>SQL transaction failed</source>
        <translation>Transazione SQL non riuscita</translation>
    </message>
    <message>
        <source>transaction: missing callback</source>
        <translation>transaction: manca funzione chiamante</translation>
    </message>
    <message>
        <source>SQL: database version mismatch</source>
        <translation>SQL: versioni di banche dati non corrispondenti</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::EnvironmentalReverb</name>
    <message>
        <source>Reverb delay (ms)</source>
        <translation>Ritardo del riverbero (ms)</translation>
    </message>
    <message>
        <source>Density (%)</source>
        <translation>Densità (%)</translation>
    </message>
    <message>
        <source>Room HF level</source>
        <translation>Livello della stanza in alta frequenza</translation>
    </message>
    <message>
        <source>Reverb level (mB)</source>
        <translation>Livello del riverbero (mB)</translation>
    </message>
    <message>
        <source>Diffusion (%)</source>
        <translation>Diffusione (%)</translation>
    </message>
    <message>
        <source>Decay HF ratio (%)</source>
        <translation>Rapporto di decadimento delle alte frequenze (%)</translation>
    </message>
    <message>
        <source>Decay time (ms)</source>
        <translation>Tempo di decadimento (ms)</translation>
    </message>
    <message>
        <source>Reflections level (mB)</source>
        <translation>Livello delle riflessioni (mB)</translation>
    </message>
    <message>
        <source>Room level (mB)</source>
        <translation>Livello della stanza (mB)</translation>
    </message>
    <message>
        <source>Reflections delay (ms)</source>
        <translation>Ritardo delle riflessioni (ms)</translation>
    </message>
</context>
<context>
    <name>QDeclarativeVME</name>
    <message>
        <source>Cannot assign object to list</source>
        <translation>Impossibile assegnare un oggetto all&apos;elenco</translation>
    </message>
    <message>
        <source>Cannot assign object type %1 with no default method</source>
        <translation>Impossibile assegnare un oggetto di tipo %1 senza metodo predefinito</translation>
    </message>
    <message>
        <source>Cannot connect mismatched signal/slot %1 %vs. %2</source>
        <translation>Impossibile connettere segnale e ricettore non corrispondenti, %1 e %2</translation>
    </message>
    <message>
        <source>Cannot assign value %1 to property %2</source>
        <translation>Impossibile assegnare un valore %1 alla proprietà %2</translation>
    </message>
    <message>
        <source>Cannot set properties on %1 as it is null</source>
        <translation>Impossibile impostare le proprietà di %1 perché è nullo</translation>
    </message>
    <message>
        <source>Cannot assign an object to signal property %1</source>
        <translation>Impossibile assegnare un oggetto alla proprietà di segnale %1</translation>
    </message>
    <message>
        <source>Unable to create object of type %1</source>
        <translation>Impossibile creare oggetto di tipo %1</translation>
    </message>
    <message>
        <source>Cannot assign object to interface property</source>
        <translation>Impossibile assegnare oggetto a proprietà di interfaccia</translation>
    </message>
    <message>
        <source>Unable to create attached object</source>
        <translation>Impossibile creare oggetto allegato</translation>
    </message>
</context>
<context>
    <name>QDB2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Unable to set autocommit</source>
        <translation>Impossibile impostare il deposito automatico</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Impossibile connettere</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
</context>
<context>
    <name>QIBaseDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>Impossibile avviare la transazione</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Errore nell&apos;apertura della banca dati</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
</context>
<context>
    <name>QIBaseResult</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Unable to open BLOB</source>
        <translation>Impossibile aprire il blob</translation>
    </message>
    <message>
        <source>Could not describe statement</source>
        <translation>Impossibile descrivere la dichiarazione</translation>
    </message>
    <message>
        <source>Could not describe input statement</source>
        <translation>Impossibile descrivere la dichiarazione di ingresso</translation>
    </message>
    <message>
        <source>Could not allocate statement</source>
        <translation>Impossibile allocare la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to write BLOB</source>
        <translation>Impossibile scrivere il blob</translation>
    </message>
    <message>
        <source>Could not start transaction</source>
        <translation>Impossibile avviare la transazione</translation>
    </message>
    <message>
        <source>Unable to close statement</source>
        <translation>Impossibile chiudere la dichiarazione</translation>
    </message>
    <message>
        <source>Could not get query info</source>
        <translation>Impossibile prelevare le informazioni dell&apos;interrogazione</translation>
    </message>
    <message>
        <source>Could not find array</source>
        <translation>Impossibile trovare l&apos;array</translation>
    </message>
    <message>
        <source>Could not get array data</source>
        <translation>Impossibile prelevare i dati dell&apos;array</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>Impossibile eseguire l&apos;interrogazione</translation>
    </message>
    <message>
        <source>Could not prepare statement</source>
        <translation>Impossibile preparare la dichiarazione</translation>
    </message>
    <message>
        <source>Could not fetch next item</source>
        <translation>Impossibile prelevare il prossimo elemento</translation>
    </message>
    <message>
        <source>Could not get statement info</source>
        <translation>Impossibile ottenere informazioni sulla dichiarazione</translation>
    </message>
    <message>
        <source>Unable to create BLOB</source>
        <translation>Impossibile creare il blob</translation>
    </message>
    <message>
        <source>Unable to read BLOB</source>
        <translation>Impossibile leggere il blob</translation>
    </message>
</context>
<context>
    <name>QMYSQLDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Unable to open database &apos;</source>
        <translation>Impossibile aprire la banca dati &apos;</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Impossibile connettere</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Impossibile avviare la transazione</translation>
    </message>
</context>
<context>
    <name>QOCIDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Unable to initialize</source>
        <comment>QOCIDriver</comment>
        <translation>Impossibile inizializzare</translation>
    </message>
    <message>
        <source>Unable to logon</source>
        <translation>Impossibile accedere</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Impossibile avviare la transazione</translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Unable to enable autocommit</source>
        <translation>Impossibile abilitare il deposito automatico</translation>
    </message>
    <message>
        <source>Unable to disable autocommit</source>
        <translation>Impossibile disabilitare il deposito automatico</translation>
    </message>
    <message>
        <source>Unable to connect - Driver doesn&apos;t support all functionality required</source>
        <translation>Impossibile connettersi: il driver non supporta tutte le funzionalità richieste</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Impossibile connettere</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
</context>
<context>
    <name>QSQLite2Driver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Errore nell&apos;apertura della banca dati</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Impossibile avviare la transazione</translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <source>Unable to commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Error closing database</source>
        <translation>Errore nella chiusura della banca dati</translation>
    </message>
    <message>
        <source>Error opening database</source>
        <translation>Errore nell&apos;apertura della banca dati</translation>
    </message>
    <message>
        <source>Unable to rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
    <message>
        <source>Unable to begin transaction</source>
        <translation>Impossibile avviare la transazione</translation>
    </message>
</context>
<context>
    <name>QAbstractSocket</name>
    <message>
        <source>Host not found</source>
        <translation>Host non trovato</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Connessione rifiutata</translation>
    </message>
    <message>
        <source>Connection timed out</source>
        <translation>Connessione scaduta</translation>
    </message>
    <message>
        <source>Socket is not connected</source>
        <translation>Socket non connesso</translation>
    </message>
    <message>
        <source>Socket operation timed out</source>
        <translation>Operazione sul socket scaduta</translation>
    </message>
    <message>
        <source>Network unreachable</source>
        <translation>Rete irraggiungibile</translation>
    </message>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>L&apos;operazione sul socket non è supportata</translation>
    </message>
</context>
<context>
    <name>QHostInfoAgent</name>
    <message>
        <source>Host not found</source>
        <translation>Host non trovato</translation>
    </message>
    <message>
        <source>No host name given</source>
        <translation>Nessun nome di host specificato</translation>
    </message>
    <message>
        <source>Unknown address type</source>
        <translation>Tipo di indirizzo sconosciuto</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Invalid hostname</source>
        <translation>Nome dell&apos;host non valido</translation>
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::MediaObject</name>
    <message>
        <source>Could not open media source.</source>
        <translation>Impossibile aprire la fonte audio/video.</translation>
    </message>
    <message>
        <source>Missing codec helper script assistant.</source>
        <translation>Assistente dello script di supporto al codec mancante.</translation>
    </message>
    <message>
        <source>Could not decode media source.</source>
        <translation>Impossibile decodificare la fonte audio/video.</translation>
    </message>
    <message>
        <source>Invalid source type.</source>
        <translation>Tipo di fonte non valido.</translation>
    </message>
    <message>
        <source>Cannot start playback. 

Check your GStreamer installation and make sure you 
have libgstreamer-plugins-base installed.</source>
        <translation>Impossibile avviare la lettura.

Controlla l&apos;installazione di GStreamer e assicurati 
di aver installato libgstreamer-plugins-base.</translation>
    </message>
    <message>
        <source>Plugin codec installation failed for codec: %0</source>
        <translation>Installazione dell&apos;estensione per codec non riuscita per il codec: %0</translation>
    </message>
    <message>
        <source>Could not open audio device. The device is already in use.</source>
        <translation>Impossibile aprire il dispositivo audio. Il dispositivo è già in uso.</translation>
    </message>
    <message>
        <source>A required codec is missing. You need to install the following codec(s) to play this content: %0</source>
        <translation>Manca un codec richiesto. Devi installare i codec seguenti per leggere questo contenuto: %0</translation>
    </message>
    <message>
        <source>Could not locate media source.</source>
        <translation>Impossibile trovare la fonte audio/video.</translation>
    </message>
</context>
<context>
    <name>QLibrary</name>
    <message>
        <source>Could not unmap &apos;%1&apos;: %2</source>
        <translation>Impossibile effettuare unmap di Â«%1Â»: %2</translation>
    </message>
    <message>
        <source>Cannot unload library %1: %2</source>
        <translation>Impossibile scaricare la libreria %1: %2</translation>
    </message>
    <message>
        <source>Cannot load library %1: %2</source>
        <translation>Impossibile caricare la libreria %1: %2</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (%2.%3.%4) [%5]</source>
        <translation>L&apos;estensione &apos;%1&apos; usa una libreria Qt non compatibile. (%2.%3.%4) [%5]</translation>
    </message>
    <message>
        <source>Cannot resolve symbol &quot;%1&quot; in %2: %3</source>
        <translation>Impossible de résoudre le symbole &quot;%1&quot; dans %2 : %3</translation>
    </message>
    <message>
        <source>Plugin verification data mismatch in &apos;%1&apos;</source>
        <translation>Dati di verifica dell&apos;estensione non corrispondenti in &apos;%1&apos;</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. (Cannot mix debug and release libraries.)</source>
        <translation>L&apos;estensione &apos;%1&apos; usa una libreria Qt non compatibile (non si possono mischiare le versioni di debug con quelle di rilascio).</translation>
    </message>
    <message>
        <source>The file &apos;%1&apos; is not a valid Qt plugin.</source>
        <translation>Il file &apos;%1&apos; non è un&apos;estensione valida di Qt.</translation>
    </message>
    <message>
        <source>The shared library was not found.</source>
        <translation>La libreria condivisa non è stata trovata.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>The plugin &apos;%1&apos; uses incompatible Qt library. Expected build key &quot;%2&quot;, got &quot;%3&quot;</source>
        <translation>Le plugin &apos;%1&apos; utilise une bibliothèque Qt incompatible. Clé attendue &quot;%2&quot;, reçue &quot;%3&quot;</translation>
    </message>
    <message>
        <source>Could not mmap &apos;%1&apos;: %2</source>
        <translation>Impossibile effettuare mmap di &apos;%1&apos;: %2</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <source>Connection refused (or timed out)</source>
        <translation>Connessione rifiutata (o scaduta)</translation>
    </message>
    <message>
        <source>Data corrupted</source>
        <translation>Data corrotta</translation>
    </message>
    <message>
        <source>Connected to host</source>
        <translation>Connessione all&apos;host</translation>
    </message>
    <message>
        <source>Connected to host %1</source>
        <translation>Connessione all&apos;host %1</translation>
    </message>
    <message>
        <source>Host %1 not found</source>
        <translation>Host %1 non trovato</translation>
    </message>
    <message>
        <source>Unknown authentication method</source>
        <translation>Metodo di autentificazione sconosciuto</translation>
    </message>
    <message>
        <source>Host requires authentication</source>
        <translation>L&apos;host richiede l&apos;autentificazione</translation>
    </message>
    <message>
        <source>Error writing response to device</source>
        <translation>Errore in scrittura durante la risposta al dispositivo</translation>
    </message>
    <message>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation>Connessione HTTPS richiesta ma il supporto SSL non è compilato in</translation>
    </message>
    <message>
        <source>Host found</source>
        <translation>Host trovato</translation>
    </message>
    <message>
        <source>Connection refused</source>
        <translation>Connessione rifiutata</translation>
    </message>
    <message>
        <source>Proxy authentication required</source>
        <translation>Autenticazione al proxy richiesta</translation>
    </message>
    <message>
        <source>Unknown protocol specified</source>
        <translation>Protocollo specificato sconosciuto</translation>
    </message>
    <message>
        <source>HTTP request failed</source>
        <translation>Richiesta HTTP fallita</translation>
    </message>
    <message>
        <source>Proxy requires authentication</source>
        <translation>Il proxy richiede un&apos;autentificazione</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Autentificazione richiesta</translation>
    </message>
    <message>
        <source>SSL handshake failed</source>
        <translation>Inizializzazione SSL fallita</translation>
    </message>
    <message>
        <source>Connection to %1 closed</source>
        <translation>Connessione a %1 chiusa</translation>
    </message>
    <message>
        <source>Invalid HTTP chunked body</source>
        <translation>Frammento HTTP non valido</translation>
    </message>
    <message>
        <source>Host %1 found</source>
        <translation>Host %1 trovato</translation>
    </message>
    <message>
        <source>Wrong content length</source>
        <translation>Lunghezza contenuto errata</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Invalid HTTP response header</source>
        <translation>Intestazione di risposta HTTP non valida</translation>
    </message>
    <message>
        <source>Connection closed</source>
        <translation>Connessione chiusa</translation>
    </message>
    <message>
        <source>No server set to connect to</source>
        <translation>Nessun server impostato per la connessione a</translation>
    </message>
    <message>
        <source>Server closed connection unexpectedly</source>
        <translation>La connessione si è interrotta inaspettatamente</translation>
    </message>
    <message>
        <source>Request aborted</source>
        <translation>Richiesta interrotta</translation>
    </message>
</context>
<context>
    <name>QDeclarativeImportDatabase</name>
    <message>
        <source>is ambiguous. Found in %1 and in %2</source>
        <translation>ambiguo. Trovato in %1 e in %2</translation>
    </message>
    <message>
        <source>local directory</source>
        <translation>cartella locale</translation>
    </message>
    <message>
        <source>import &quot;%1&quot; has no qmldir and no namespace</source>
        <translation>l&apos;importazione &apos;%1&apos; non ha qmldir né spazio di nomi</translation>
    </message>
    <message>
        <source>- %1 is not a namespace</source>
        <translation>- %1 non è uno spazio di nomi</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; definition &quot;%2&quot; not readable</source>
        <translation>definizione &quot;%2&quot; per il modulo &quot;%1% non leggibile</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; plugin &quot;%2&quot; not found</source>
        <translation>plugin &quot;%2&quot; per il modulo &quot;%1&quot; non trovato</translation>
    </message>
    <message>
        <source>is not a type</source>
        <translation>non è un tipo</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; is not installed</source>
        <translation>il modulo &quot;%1&quot; non è installato</translation>
    </message>
    <message>
        <source>module &quot;%1&quot; version %2.%3 is not installed</source>
        <translation>la versione %2.%3 del modulo &quot;%1&quot; non è installata</translation>
    </message>
    <message>
        <source>- nested namespaces not allowed</source>
        <translation>- spazi di nomi annidati non permessi</translation>
    </message>
    <message>
        <source>plugin cannot be loaded for module &quot;%1&quot;: %2</source>
        <translation>plugin non caricabile per il modulo &quot;%1&quot; : %2</translation>
    </message>
    <message>
        <source>is instantiated recursively</source>
        <translation>è istanziato ricorsivamente</translation>
    </message>
    <message>
        <source>is ambiguous. Found in %1 in version %2.%3 and %4.%5</source>
        <translation>ambiguo. Trovato in %1 in versione %2.%3 e %4.%5</translation>
    </message>
    <message>
        <source>&quot;%1&quot;: no such directory</source>
        <translation>&quot;%1&quot;: cartella inesistente</translation>
    </message>
</context>
<context>
    <name>QXml</name>
    <message>
        <source>unparsed entity reference in wrong context</source>
        <translation>riferimento a entità non analizzata in contesto errato</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in DTD</source>
        <translation>riferimento a entità esterna generale analizzata non consetito nella DTD</translation>
    </message>
    <message>
        <source>wrong value for standalone declaration</source>
        <translation>valore errato per la dichiarazione &quot;standalone&quot;</translation>
    </message>
    <message>
        <source>encoding declaration or standalone declaration expected while reading the XML declaration</source>
        <translation>attesa una dichiarazione di codifica o una dichiarazione &quot;standalone&quot; nella lettura della dichiarazione XML</translation>
    </message>
    <message>
        <source>no error occurred</source>
        <translation>nessun errore</translation>
    </message>
    <message>
        <source>error occurred while parsing reference</source>
        <translation>errore nell&apos;analisi del riferimento</translation>
    </message>
    <message>
        <source>standalone declaration expected while reading the XML declaration</source>
        <translation>attesa dichiarazione &quot;standalone&quot; nella lettura della dichiarazione XML</translation>
    </message>
    <message>
        <source>invalid name for processing instruction</source>
        <translation>nome non valido per l&apos;istruzione di elaborazione</translation>
    </message>
    <message>
        <source>error triggered by consumer</source>
        <translation>errore causato dal consumatore</translation>
    </message>
    <message>
        <source>error occurred while parsing element</source>
        <translation>errore nell&apos;analisi dell&apos;elemento</translation>
    </message>
    <message>
        <source>unexpected character</source>
        <translation>carattere inatteso</translation>
    </message>
    <message>
        <source>tag mismatch</source>
        <translation>marcatori non corrispondenti</translation>
    </message>
    <message>
        <source>error occurred while parsing content</source>
        <translation>errore nell&apos;analisi del contenuto</translation>
    </message>
    <message>
        <source>error occurred while parsing comment</source>
        <translation>errore nell&apos;analisi del commento</translation>
    </message>
    <message>
        <source>internal general entity reference not allowed in DTD</source>
        <translation>riferimento a entità interna generale non consentito nella DTD</translation>
    </message>
    <message>
        <source>recursive entities</source>
        <translation>entità ricorsive</translation>
    </message>
    <message>
        <source>more than one document type definition</source>
        <translation>più di una DTD</translation>
    </message>
    <message>
        <source>version expected while reading the XML declaration</source>
        <translation>attesa versione nella lettura della dichiarazione XML</translation>
    </message>
    <message>
        <source>letter is expected</source>
        <translation>attesa una lettera</translation>
    </message>
    <message>
        <source>unexpected end of file</source>
        <translation>fine di file inattesa</translation>
    </message>
    <message>
        <source>external parsed general entity reference not allowed in attribute value</source>
        <translation>riferimento a entità esterna generale analizzata non consentito in un valore di attributo</translation>
    </message>
    <message>
        <source>error in the text declaration of an external entity</source>
        <translation>errore nella dichiarazione del testo di un&apos;entità esterna</translation>
    </message>
    <message>
        <source>error occurred while parsing document type definition</source>
        <translation>errore nell&apos;analisi della DTD</translation>
    </message>
</context>
<context>
    <name>QSystemSemaphore</name>
    <message>
        <source>%1: does not exist</source>
        <translation>%1: non esiste</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <translation>%1: esiste già</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <translation>%1: errore sconosciuto %2</translation>
    </message>
    <message>
        <source>%1: permission denied</source>
        <translation>%1: permesso negato</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <translation>%1: risorse insufficienti</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::MediaObject</name>
    <message>
        <source>Error opening source: resource is compressed</source>
        <translation>Errore nell&apos;apertura della fonte: risorsa compressa</translation>
    </message>
    <message>
        <source>Error opening source: media type could not be determined</source>
        <translation>Errore nell&apos;apertura della fonte: impossibile determinare il tipo di audio o video</translation>
    </message>
    <message>
        <source>Error opening source: resource not valid</source>
        <translation>Errore nell&apos;apertura della fonte: risorsa non valida</translation>
    </message>
    <message>
        <source>Error opening source: type not supported</source>
        <translation>Errore nell&apos;apertura della fonte: tipo non supportato</translation>
    </message>
</context>
<context>
    <name>QDeclarativePixmap</name>
    <message>
        <source>Error decoding: %1: %2</source>
        <translation>Errore nella decodifica: %1: %2</translation>
    </message>
    <message>
        <source>Cannot open: %1</source>
        <translation>Impossibile aprire: %1</translation>
    </message>
    <message>
        <source>Failed to get image from provider: %1</source>
        <translation>Recupero dell&apos;immagine dal fornitore non riuscita: %1</translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <source>Unable to fetch row</source>
        <translation>Impossibile prelevare la riga</translation>
    </message>
    <message>
        <source>No query</source>
        <translation>Nessuna interrogazione</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Impossibile eseguire la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to bind parameters</source>
        <translation>Impossibile collegare i parametri</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>Impossibile azzerare la dichiarazione</translation>
    </message>
    <message>
        <source>Parameter count mismatch</source>
        <translation>Numero di parametri non corrispondente</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <source>Activates the program&apos;s main window</source>
        <translation>Attiva la finestra principale del programma</translation>
    </message>
    <message>
        <source>QT_LAYOUT_DIRECTION</source>
        <comment>Translate this string to the string &apos;LTR&apos; in left-to-right languages or to &apos;RTL&apos; in right-to-left languages (such as Hebrew and Arabic) to get proper widget layout.</comment>
        <translation>LTR</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>Attiva</translation>
    </message>
    <message>
        <source>Executable &apos;%1&apos; requires Qt %2, found Qt %3.</source>
        <translation>L&apos;esecuzione &apos;%1&apos; richiede Qt %2 mentre è stato rilevato Qt %3.</translation>
    </message>
    <message>
        <source>Incompatible Qt Library Error</source>
        <translation>Errore d&apos;incompatibilità delle librerie Qt</translation>
    </message>
</context>
<context>
    <name>QDeclarativeBinding</name>
    <message>
        <source>Binding loop detected for property &quot;%1&quot;</source>
        <translation>Ciclo di collegamento rilevato per la proprietà &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeBindings</name>
    <message>
        <source>Binding loop detected for property &quot;%1&quot;</source>
        <translation>Ciclo di collegamento rilevato per la proprietà &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QUnicodeControlCharacterMenu</name>
    <message>
        <source>RLE Start of right-to-left embedding</source>
        <translation>RLE inizio incorporamento da destra a sinistra</translation>
    </message>
    <message>
        <source>ZWSP Zero width space</source>
        <translation>ZWJ spazio di ampiezza zero</translation>
    </message>
    <message>
        <source>Insert Unicode control character</source>
        <translation>Inserisci carattere di controllo Unicode</translation>
    </message>
    <message>
        <source>LRO Start of left-to-right override</source>
        <translation>LRO inizio forzatura da sinistra a destra</translation>
    </message>
    <message>
        <source>LRE Start of left-to-right embedding</source>
        <translation>LRE inizio incorporamento da sinistra a destra</translation>
    </message>
    <message>
        <source>RLM Right-to-left mark</source>
        <translation>RLM indicatore di direzione da destra a sinistra</translation>
    </message>
    <message>
        <source>PDF Pop directional formatting</source>
        <translation>PDF ripristina impostazioni di direzione del testo</translation>
    </message>
    <message>
        <source>ZWNJ Zero width non-joiner</source>
        <translation>ZWNJ carattere non congiungente di ampiezza zero</translation>
    </message>
    <message>
        <source>RLO Start of right-to-left override</source>
        <translation>RLO inizio forzatura da destra a sinistra </translation>
    </message>
    <message>
        <source>ZWJ Zero width joiner</source>
        <translation>ZWJ carattere congiungente di ampiezza zero</translation>
    </message>
    <message>
        <source>LRM Left-to-right mark</source>
        <translation>LRM indicatore di direzione da sinistra a destra</translation>
    </message>
</context>
<context>
    <name>QWebFrame</name>
    <message>
        <source>Request blocked</source>
        <translation>Richiesta bloccata</translation>
    </message>
    <message>
        <source>Frame load interrupted by policy change</source>
        <translation>Caricamento riquadro interrotto dalla modifica dei criteri</translation>
    </message>
    <message>
        <source>Request cancelled</source>
        <translation>Richiesta annullata</translation>
    </message>
    <message>
        <source>Cannot show URL</source>
        <translation>Impossibile mostrare l&apos;URL</translation>
    </message>
    <message>
        <source>File does not exist</source>
        <translation>Il file non esiste</translation>
    </message>
    <message>
        <source>Cannot show mimetype</source>
        <translation>Impossible mostrare il Tipo MIME</translation>
    </message>
</context>
<context>
    <name>QHttpSocketEngine</name>
    <message>
        <source>Proxy connection refused</source>
        <translation>Connessione al proxy rifiutata</translation>
    </message>
    <message>
        <source>Proxy denied connection</source>
        <translation>Connessione al proxy negata</translation>
    </message>
    <message>
        <source>Proxy server not found</source>
        <translation>Connessione al serveur non rilevata</translation>
    </message>
    <message>
        <source>Proxy server connection timed out</source>
        <translation>Connessione al server proxy scaduta</translation>
    </message>
    <message>
        <source>Did not receive HTTP response from proxy</source>
        <translation>Non è stata ricevuta alcuna risposta HTTP dal proxy</translation>
    </message>
    <message>
        <source>Proxy connection closed prematurely</source>
        <translation>La connessione al proxy si è chiusa prematuramente</translation>
    </message>
    <message>
        <source>Error communicating with HTTP proxy</source>
        <translation>Errore di comunicazione con il proxy HTTP</translation>
    </message>
    <message>
        <source>Authentication required</source>
        <translation>Autentificazione richiesta</translation>
    </message>
    <message>
        <source>Error parsing authentication request from proxy</source>
        <translation>Errore durante l&apos;analsi di autentificazione richiesta da parte del proxy</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessManager</name>
    <message>
        <source>Network access is disabled.</source>
        <translation>L&apos;accesso alla rete è disabilitato.</translation>
    </message>
</context>
<context>
    <name>QNetworkReply</name>
    <message>
        <source>Error downloading %1 - server replied: %2</source>
        <translation>Errore nello scaricamento di %1; il server ha risposto: %2</translation>
    </message>
    <message>
        <source>Network session error.</source>
        <translation>Errore nella sessione di rete.</translation>
    </message>
    <message>
        <source>Protocol &quot;%1&quot; is unknown</source>
        <translation>Le protocole &quot;%1&quot; est inconnu</translation>
    </message>
    <message>
        <source>Temporary network failure.</source>
        <translation>Errore di rete temporaneo.</translation>
    </message>
</context>
<context>
    <name>QAbstractSpinBox</name>
    <message>
        <source>Step &amp;down</source>
        <translation>Sposta in &amp;basso</translation>
    </message>
    <message>
        <source>&amp;Step up</source>
        <translation>Sposta in &amp;alto</translation>
    </message>
    <message>
        <source>&amp;Select All</source>
        <translation>Seleziona &amp;tutto</translation>
    </message>
</context>
<context>
    <name>QDeclarativeXmlRoleList</name>
    <message>
        <source>An XmlListModel query must start with &apos;/&apos; or &quot;//&quot;</source>
        <translation>Un&apos;interrogazione XmlListModel deve iniziare per &apos;/&apos; o &quot;//&quot;</translation>
    </message>
</context>
<context>
    <name>QDB2Result</name>
    <message>
        <source>Unable to bind variable</source>
        <translation>Impossibile collegare la variabile</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Impossibile eseguire la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>Impossibile prelevare il successivo</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Impossibile preparare la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to fetch record %1</source>
        <translation>Impossibile prelevare il record %1</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>Impossibile prelevare il primo</translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <source>Unable to bind variable</source>
        <translation>Impossibile collegare la variabile</translation>
    </message>
    <message>
        <source>Unable to execute statement</source>
        <translation>Impossibile eseguire la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to fetch next</source>
        <translation>Impossibile prelevare il successivo</translation>
    </message>
    <message>
        <source>Unable to fetch last</source>
        <translation>Impossibile prelevare l&apos;ultimo</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Impossibile preparare la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to fetch previous</source>
        <translation>Impossibile prelevare il precedente</translation>
    </message>
    <message>
        <source>Unable to fetch</source>
        <translation>Impossibile prelevare</translation>
    </message>
    <message>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation>QODBCResult::reset: Impossibile impostare &apos;SQL_CURSOR_STATIC&apos; come un attributo della dichiarazione. Controlla la configurazione del driver ODBC.</translation>
    </message>
    <message>
        <source>Unable to fetch first</source>
        <translation>Impossibile prelevare il primo</translation>
    </message>
</context>
<context>
    <name>QPSQLDriver</name>
    <message>
        <source>Unable to subscribe</source>
        <translation>Impossibile iscriversi</translation>
    </message>
    <message>
        <source>Could not begin transaction</source>
        <translation>Impossibile iniziare la transazione</translation>
    </message>
    <message>
        <source>Could not rollback transaction</source>
        <translation>Impossibile annullare la transazione</translation>
    </message>
    <message>
        <source>Could not commit transaction</source>
        <translation>Impossibile depositare la transazione</translation>
    </message>
    <message>
        <source>Unable to connect</source>
        <translation>Impossibile connettere</translation>
    </message>
    <message>
        <source>Unable to unsubscribe</source>
        <translation>Impossibile deiscriversi</translation>
    </message>
</context>
<context>
    <name>QInputDialog</name>
    <message>
        <source>Enter a value:</source>
        <translation>Inserisci un valore:</translation>
    </message>
</context>
<context>
    <name>QIODevice</name>
    <message>
        <source>No such file or directory</source>
        <translation>File o cartella inesistente</translation>
    </message>
    <message>
        <source>Permission denied</source>
        <translation>Permesso negato</translation>
    </message>
    <message>
        <source>No space left on device</source>
        <translation>Non c&apos;è più spazio sul dispositivo</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Too many open files</source>
        <translation>Troppi file aperti</translation>
    </message>
</context>
<context>
    <name>FakeReply</name>
    <message>
        <source>Invalid URL</source>
        <translation>URL non valido</translation>
    </message>
    <message>
        <source>Fake error !</source>
        <translation>Errore finto!</translation>
    </message>
</context>
<context>
    <name>QMultiInputContext</name>
    <message>
        <source>Select IM</source>
        <translation>Seleziona metodo d&apos;inserimento</translation>
    </message>
</context>
<context>
    <name>QTabBar</name>
    <message>
        <source>Scroll Left</source>
        <translation>Scorri a sinistra</translation>
    </message>
    <message>
        <source>Scroll Right</source>
        <translation>Scorri a destra</translation>
    </message>
</context>
<context>
    <name>QUndoModel</name>
    <message>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vuoto&gt;</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessCacheBackend</name>
    <message>
        <source>Error opening %1</source>
        <translation>Errore nell&apos;apertura di %1</translation>
    </message>
</context>
<context>
    <name>QDeclarativeParser</name>
    <message>
        <source>Script import qualifiers must be unique.</source>
        <translation>I qualificatori di importazione degli script devono essere univoci.</translation>
    </message>
    <message>
        <source>Unterminated regular expression class</source>
        <translation>Classe di espressioni regolari non conclusa</translation>
    </message>
    <message>
        <source>Library import requires a version</source>
        <translation>L&apos;importazione di librerie richiede una versione</translation>
    </message>
    <message>
        <source>Invalid regular expression flag &apos;%0&apos;</source>
        <translation>Contrassegno non valido per espressione regolare &apos;%0&apos;</translation>
    </message>
    <message>
        <source>JavaScript declaration outside Script element</source>
        <translation>Dichiarazione JavaScript al di fuori di un elemento Script</translation>
    </message>
    <message>
        <source>Illegal character</source>
        <translation>Carattere non consentito</translation>
    </message>
    <message>
        <source>Unclosed comment at end of file</source>
        <translation>Commento non concluso alla fine del file</translation>
    </message>
    <message>
        <source>Unclosed string at end of line</source>
        <translation>Stringa non conclusa alla fine della riga</translation>
    </message>
    <message>
        <source>Expected property type</source>
        <translation>Era atteso un tipo di proprietà </translation>
    </message>
    <message>
        <source>Expected type name</source>
        <translation>Era atteso un nome di tipo</translation>
    </message>
    <message>
        <source>Illegal escape sequence</source>
        <translation>Sequenza di escape non consentita</translation>
    </message>
    <message>
        <source>Readonly not yet supported</source>
        <translation>Sola lettura non ancora supportata</translation>
    </message>
    <message>
        <source>Unterminated regular expression literal</source>
        <translation>Letterale a espressione regolare non concluso</translation>
    </message>
    <message>
        <source>Property value set multiple times</source>
        <translation>Valore della proprietà impostato più volte</translation>
    </message>
    <message>
        <source>Unterminated regular expression backslash sequence</source>
        <translation>Sequenza con barra inversa di espressione regolare non conclusa</translation>
    </message>
    <message>
        <source>Identifier cannot start with numeric literal</source>
        <translation>L&apos;identificativo non può cominciare con un letterale numerico</translation>
    </message>
    <message>
        <source>Script import requires a qualifier</source>
        <translation>L&apos;importazione di script richiede un qualificatore</translation>
    </message>
    <message>
        <source>Illegal syntax for exponential number</source>
        <translation>Sintassi non consentita per numero esponenziale</translation>
    </message>
    <message>
        <source>Invalid property type modifier</source>
        <translation>Modificatore del tipo di proprietà non valido</translation>
    </message>
    <message>
        <source>Reserved name &quot;Qt&quot; cannot be used as an qualifier</source>
        <translation>Il nome riservato&quot;Qt&quot; non può essere usato come qualificatore</translation>
    </message>
    <message>
        <source>Expected token `%1&apos;</source>
        <translation>Elemento atteso &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Unexpected token `%1&apos;</source>
        <translation>Elemento inatteso &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Expected parameter type</source>
        <translation>Era atteso un tipo di parametro</translation>
    </message>
    <message>
        <source>Illegal unicode escape sequence</source>
        <translation>Sequenza di escape Unicode non consentita</translation>
    </message>
    <message>
        <source>Unexpected property type modifier</source>
        <translation>Modificatore del tipo di proprietà inatteso</translation>
    </message>
    <message>
        <source>Invalid import qualifier ID</source>
        <translation>Identificativo del qualificatore d&apos;importazione non valido</translation>
    </message>
    <message>
        <source>Syntax error</source>
        <translation>Errore di sintassi</translation>
    </message>
</context>
<context>
    <name>QScriptEdit</name>
    <message>
        <source>Disable Breakpoint</source>
        <translation>Disabilita punto di interruzione</translation>
    </message>
    <message>
        <source>Breakpoint Condition:</source>
        <translation>Condizione del punto di interruzione:</translation>
    </message>
    <message>
        <source>Toggle Breakpoint</source>
        <translation>Commuta punto di interruzione</translation>
    </message>
    <message>
        <source>Enable Breakpoint</source>
        <translation>Abilita punto di interruzione</translation>
    </message>
</context>
<context>
    <name>QMYSQLResult</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>Impossibile eseguire la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to store statement results</source>
        <translation>Impossibile memorizzare i risultati della dichiarazione</translation>
    </message>
    <message>
        <source>Unable to execute next query</source>
        <translation>Impossibile eseguire l&apos;interrogazione successiva</translation>
    </message>
    <message>
        <source>Unable to bind outvalues</source>
        <translation>Impossibile collegare i valori in uscita</translation>
    </message>
    <message>
        <source>Unable to store next result</source>
        <translation>Impossibile memorizzare il prossimo risultato</translation>
    </message>
    <message>
        <source>Unable to fetch data</source>
        <translation>Impossibile prelevare dati</translation>
    </message>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Impossibile preparare la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to store result</source>
        <translation>Impossibile memorizzare il risultato</translation>
    </message>
    <message>
        <source>Unable to bind value</source>
        <translation>Impossibile collegare il valore</translation>
    </message>
    <message>
        <source>Unable to execute query</source>
        <translation>Impossibile eseguire l&apos;interrogazione</translation>
    </message>
    <message>
        <source>Unable to reset statement</source>
        <translation>Impossibile azzerare la dichiarazione</translation>
    </message>
</context>
<context>
    <name>QSQLite2Result</name>
    <message>
        <source>Unable to execute statement</source>
        <translation>Impossibile eseguire la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to fetch results</source>
        <translation>Impossibile prelevare i risultati</translation>
    </message>
</context>
<context>
    <name>Phonon::AudioOutput</name>
    <message>
        <source>&lt;html&gt;Switching to the audio playback device &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt;which has higher preference or is specifically configured for this stream.&lt;/html&gt;</source>
        <translation>&lt;html&gt;Passo al dispositivo di lettura audio &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt; che ha maggiore preferenza o è configurato specificamente per questo flusso.&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;The audio playback device &lt;b&gt;%1&lt;/b&gt; does not work.&lt;br/&gt;Falling back to &lt;b&gt;%2&lt;/b&gt;.&lt;/html&gt;</source>
        <translation>&lt;html&gt;Il dispositivo di lettura audio &lt;b&gt;%1&lt;/b&gt; non funziona.&lt;br/&gt;Ripiego su &lt;b&gt;%2&lt;/b&gt;.&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Revert back to device &apos;%1&apos;</source>
        <translation>Ritorno al dispositivo &apos;%1&apos;</translation>
    </message>
    <message>
        <source>&lt;html&gt;Switching to the audio playback device &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt;which just became available and has higher preference.&lt;/html&gt;</source>
        <translation>&lt;html&gt;Passo al dispositivo di lettura audio &lt;b&gt;%1&lt;/b&gt;&lt;br/&gt; che è appena diventato disponibile e ha una preferenza maggiore.&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>Q3MainWindow</name>
    <message>
        <source>Line up</source>
        <translation>Allinea</translation>
    </message>
    <message>
        <source>Customize...</source>
        <translation>Personalizza...</translation>
    </message>
</context>
<context>
    <name>QUdpSocket</name>
    <message>
        <source>This platform does not support IPv6</source>
        <translation>Questa piattaforma non supporta IPv6</translation>
    </message>
</context>
<context>
    <name>Phonon::Gstreamer::Backend</name>
    <message>
        <source>Warning: You do not seem to have the base GStreamer plugins installed.
          All audio and video support has been disabled</source>
        <translation>Avviso: sembra che le estensioni fondamentali di GStreamer non siano installate.
          Il supporto audio e video è stato disabilitato.</translation>
    </message>
    <message>
        <source>Warning: You do not seem to have the package gstreamer0.10-plugins-good installed.
          Some video features have been disabled.</source>
        <translation>Avviso: sembra che il pacchetto gstreamer0.10-plugins-good non sia installato.
          Alcune funzioni video sono state disabilitate.</translation>
    </message>
</context>
<context>
    <name>QDeclarativePropertyChanges</name>
    <message>
        <source>Cannot assign to read-only property &quot;%1&quot;</source>
        <translation>Impossibile assegnare alla proprietà di sola lettura &quot;%1&quot;</translation>
    </message>
    <message>
        <source>PropertyChanges does not support creating state-specific objects.</source>
        <translation>PropertyChanges non supporta la creazione di oggetti a stato specifico.</translation>
    </message>
    <message>
        <source>Cannot assign to non-existent property &quot;%1&quot;</source>
        <translation>Impossibile assegnare una proprietà  inesistente &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QLocalServer</name>
    <message>
        <source>%1: Name error</source>
        <translation>%1: errore nel nome</translation>
    </message>
    <message>
        <source>%1: Unknown error %2</source>
        <translation>%1: errore sconosciuto %2</translation>
    </message>
    <message>
        <source>%1: Permission denied</source>
        <translation>%1: permesso negato</translation>
    </message>
    <message>
        <source>%1: Address in use</source>
        <translation>%1: Indirizzo già in uso</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AbstractVideoPlayer</name>
    <message>
        <source>Pause failed</source>
        <translation>Pausa non riuscita</translation>
    </message>
    <message>
        <source>Seek failed</source>
        <translation>Spostamento non riuscito</translation>
    </message>
    <message>
        <source>Opening clip failed</source>
        <translation>Apertura dello spezzone non riuscita</translation>
    </message>
    <message>
        <source>Getting position failed</source>
        <translation>Recupero della posizione non riuscito</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AbstractMediaPlayer</name>
    <message>
        <source>Not ready to play</source>
        <translation>Non pronto alla lettura</translation>
    </message>
    <message>
        <source>Error opening file</source>
        <translation>Errore nell&apos;apertura del file</translation>
    </message>
    <message>
        <source>Error opening source: resource not opened</source>
        <translation>Errore nell&apos;apertura della fonte: risorsa non aperta</translation>
    </message>
    <message>
        <source>Error opening URL</source>
        <translation>Errore nell&apos;apertura dell&apos;URL</translation>
    </message>
    <message>
        <source>Loading clip failed</source>
        <translation>Caricamento dello spezzone non riuscito</translation>
    </message>
    <message>
        <source>Setting volume failed</source>
        <translation>Impostazione del volume non riuscita</translation>
    </message>
    <message>
        <source>Error opening resource</source>
        <translation>Errore nell&apos;apertura della risorsa</translation>
    </message>
    <message>
        <source>Playback complete</source>
        <translation>Lettura completata</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAbstractAnimation</name>
    <message>
        <source>Animation is an abstract class</source>
        <translation>L&apos;animazione è una classe astratta</translation>
    </message>
    <message>
        <source>Cannot animate non-existent property &quot;%1&quot;</source>
        <translation>Impossibile animare la proprietà inesistente &quot;%1&quot;</translation>
    </message>
    <message>
        <source>Cannot animate read-only property &quot;%1&quot;</source>
        <translation>Impossibile animare la proprietà di sola lettura &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QCoreApplication</name>
    <message>
        <source>%1: unable to make key</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: impossibile creare la chiave</translation>
    </message>
    <message>
        <source>%1: ftok failed</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: ftok non riuscito</translation>
    </message>
    <message>
        <source>%1: out of resources</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: risorse insufficienti</translation>
    </message>
    <message>
        <source>%1: does not exist</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: non esiste</translation>
    </message>
    <message>
        <source>%1: unknown error %2</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: errore sconosciuto %2</translation>
    </message>
    <message>
        <source>%1: key is empty</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: la chiave è vuota</translation>
    </message>
    <message>
        <source>%1: already exists</source>
        <comment>QSystemSemaphore</comment>
        <translation>%1: esiste già</translation>
    </message>
</context>
<context>
    <name>QDeclarativeFlipable</name>
    <message>
        <source>front is a write-once property</source>
        <translation>&apos;front&apos; (fronte) è una proprietà scrivibile una volta sola</translation>
    </message>
    <message>
        <source>back is a write-once property</source>
        <translation>&apos;back&apos; (retro) è una proprietà scrivibile una volta sola</translation>
    </message>
</context>
<context>
    <name>Q3ToolBar</name>
    <message>
        <source>More...</source>
        <translation>Altro...</translation>
    </message>
</context>
<context>
    <name>QDeclarativeParentAnimation</name>
    <message>
        <source>Unable to preserve appearance under non-uniform scale</source>
        <translation>Impossibile mantenere l&apos;aspetto in riscalamento non uniforme</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under complex transform</source>
        <translation>Impossibile mantenere l&apos;aspetto in trasformazione complessa</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under scale of 0</source>
        <translation>Impossibile mantenere l&apos;aspetto in scala di 0</translation>
    </message>
</context>
<context>
    <name>QDeclarativeParentChange</name>
    <message>
        <source>Unable to preserve appearance under non-uniform scale</source>
        <translation>Impossibile mantenere l&apos;aspetto in riscalamento non uniforme</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under complex transform</source>
        <translation>Impossibile mantenere l&apos;aspetto in trasformazione complessa</translation>
    </message>
    <message>
        <source>Unable to preserve appearance under scale of 0</source>
        <translation>Impossibile mantenere l&apos;aspetto in scala di 0</translation>
    </message>
</context>
<context>
    <name>QMultiInputContextPlugin</name>
    <message>
        <source>Multiple input method switcher that uses the context menu of the text widgets</source>
        <translation>Cambio multiplo del metodo d&apos;inserimento che usa il menu contestuale degli campi di testo</translation>
    </message>
    <message>
        <source>Multiple input method switcher</source>
        <translation>Cambio multiplo del metodo d&apos;inserimento</translation>
    </message>
</context>
<context>
    <name>Q3ProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>QProgressDialog</name>
    <message>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>QGstreamerPlayerSession</name>
    <message>
        <source>Unable to play %1</source>
        <translation>Impossibile leggere %1</translation>
    </message>
</context>
<context>
    <name>QDeclarativeComponent</name>
    <message>
        <source>Invalid empty URL</source>
        <translation>URL vuoto non valido</translation>
    </message>
</context>
<context>
    <name>MAC_APPLICATION_MENU</name>
    <message>
        <source>Hide Others</source>
        <translation>Nascondi gli altri</translation>
    </message>
    <message>
        <source>Quit %1</source>
        <translation>Esci da %1</translation>
    </message>
    <message>
        <source>About %1</source>
        <translation>Informazioni su %1</translation>
    </message>
    <message>
        <source>Preferences...</source>
        <translation>Preferenze...</translation>
    </message>
    <message>
        <source>Services</source>
        <translation>Servizi</translation>
    </message>
    <message>
        <source>Hide %1</source>
        <translation>Nascondi %1</translation>
    </message>
    <message>
        <source>Show All</source>
        <translation>Mostra tutto</translation>
    </message>
</context>
<context>
    <name>QTDSDriver</name>
    <message>
        <source>Unable to open connection</source>
        <translation>Impossibile aprire la connessione</translation>
    </message>
    <message>
        <source>Unable to use database</source>
        <translation>Impossibile usare la banca dati</translation>
    </message>
</context>
<context>
    <name>QDeclarativeVisualDataModel</name>
    <message>
        <source>Delegate component must be Item type.</source>
        <translation>Il componente delegato deve essere di tipo Item.</translation>
    </message>
</context>
<context>
    <name>QMediaPlaylist</name>
    <message>
        <source>The file could not be accessed.</source>
        <translation>Impossibile accedere al file.</translation>
    </message>
    <message>
        <source>Could not add items to read only playlist.</source>
        <translation>Impossibile aggiungere elementi alla scaletta in sola lettura dei file multimediali da riprodurre.</translation>
    </message>
    <message>
        <source>Playlist format is not supported</source>
        <translation>Il formato della scaletta dei file multimediali da riprodurre non è supportato</translation>
    </message>
</context>
<context>
    <name>QDeclarativeConnections</name>
    <message>
        <source>Connections: script expected</source>
        <translation>Connections: era atteso uno script</translation>
    </message>
    <message>
        <source>Connections: nested objects not allowed</source>
        <translation>Connections: oggetti annidati non permessi</translation>
    </message>
    <message>
        <source>Cannot assign to non-existent property &quot;%1&quot;</source>
        <translation>Impossibile assegnare alla proprietà inesistente&quot;%1&quot;</translation>
    </message>
    <message>
        <source>Connections: syntax error</source>
        <translation>Connections: errore di sintassi</translation>
    </message>
</context>
<context>
    <name>QPluginLoader</name>
    <message>
        <source>The plugin was not loaded.</source>
        <translation>L&apos;estensione non è stata caricata.</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
</context>
<context>
    <name>QSlider</name>
    <message>
        <source>Page up</source>
        <translation>Pagina sù</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Posizione</translation>
    </message>
    <message>
        <source>Page right</source>
        <translation>Pagina destra</translation>
    </message>
    <message>
        <source>Page down</source>
        <translation>Pagina giù</translation>
    </message>
    <message>
        <source>Page left</source>
        <translation>Pagina sinistra</translation>
    </message>
</context>
<context>
    <name>CloseButton</name>
    <message>
        <source>Close Tab</source>
        <translation>Chiudi scheda</translation>
    </message>
</context>
<context>
    <name>QPSQLResult</name>
    <message>
        <source>Unable to prepare statement</source>
        <translation>Impossibile preparare la dichiarazione</translation>
    </message>
    <message>
        <source>Unable to create query</source>
        <translation>Impossibile creare l&apos;interrogazione</translation>
    </message>
</context>
<context>
    <name>QNetworkSession</name>
    <message>
        <source>Invalid configuration.</source>
        <translation>Configurazione non valida.</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDataBackend</name>
    <message>
        <source>Invalid URI: %1</source>
        <translation>URI non valido: %1</translation>
    </message>
    <message>
        <source>Operation not supported on %1</source>
        <translation>Operazione non supportata su %1</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAnimatedImage</name>
    <message>
        <source>Qt was built without support for QMovie</source>
        <translation>Qt è stato generato senza supporto per QMovie</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>&quot;%1&quot; duplicates a previous role name and will be disabled.</source>
        <translation>&quot;%1&quot; duplica un nome di ruolo precedente e sarà disabilitato.</translation>
    </message>
    <message>
        <source>PulseAudio Sound Server</source>
        <translation>Server sonoro PulseAudio</translation>
    </message>
    <message>
        <source>invalid query: &quot;%1&quot;</source>
        <translation>interrogazione non valida: &quot;%1&quot;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeKeysAttached</name>
    <message>
        <source>Keys is only available via attached properties</source>
        <translation>Keys è disponibile solo attraverso proprietà allegate</translation>
    </message>
</context>
<context>
    <name>QMenuBar</name>
    <message>
        <source>Actions</source>
        <translation>Azioni</translation>
    </message>
</context>
<context>
    <name>QMediaPlayer</name>
    <message>
        <source>The QMediaPlayer object does not have a valid service</source>
        <translation>L&apos;oggetto QMediaPlayer non presenta un servizio valido</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessDebugPipeBackend</name>
    <message>
        <source>Socket error on %1: %2</source>
        <translation>Errore di socket su %1: %2</translation>
    </message>
    <message>
        <source>Remote host closed the connection prematurely on %1</source>
        <translation>L&apos;host remoto ha chiuso la connessione prematuramente su %1</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Errore nella scrittura su %1: %2</translation>
    </message>
</context>
<context>
    <name>QNetworkAccessFileBackend</name>
    <message>
        <source>Request for opening non-local file %1</source>
        <translation>Richiesta di apertura di file non locale %1</translation>
    </message>
    <message>
        <source>Read error reading from %1: %2</source>
        <translation>Errore nella lettura da %1: %2</translation>
    </message>
    <message>
        <source>Cannot open %1: Path is a directory</source>
        <translation>Impossibile aprire %1: il percorso è una cartella</translation>
    </message>
    <message>
        <source>Error opening %1: %2</source>
        <translation>Errore nell&apos;apertura di %1: %2</translation>
    </message>
    <message>
        <source>Write error writing to %1: %2</source>
        <translation>Errore nella scrittura su %1: %2</translation>
    </message>
</context>
<context>
    <name>QHostInfo</name>
    <message>
        <source>No host name given</source>
        <translation>Nessun nome di host specificato</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
</context>
<context>
    <name>QDeclarativeLoader</name>
    <message>
        <source>Loader does not support loading non-visual elements.</source>
        <translation>Il caricatore non supporta il caricamento di elementi non visivi.</translation>
    </message>
</context>
<context>
    <name>QNetworkReplyImpl</name>
    <message>
        <source>Operation canceled</source>
        <translation>Operazione annullata</translation>
    </message>
</context>
<context>
    <name>Q3NetworkProtocol</name>
    <message>
        <source>Operation stopped by the user</source>
        <translation>Operazione interrotta dall&apos;utente</translation>
    </message>
</context>
<context>
    <name>QStateMachine</name>
    <message>
        <source>Missing default state in history state &apos;%1&apos;</source>
        <translation>Stato predefinito mancante nello stato cronologico &apos;%1&apos;</translation>
    </message>
    <message>
        <source>Unknown error</source>
        <translation>Errore sconosciuto</translation>
    </message>
    <message>
        <source>Missing initial state in compound state &apos;%1&apos;</source>
        <translation>Stato iniziale mancante nello stato composto &apos;%1&apos;</translation>
    </message>
    <message>
        <source>No common ancestor for targets and source of transition from state &apos;%1&apos;</source>
        <translation>Nessun antenato comune per le destinazioni e l&apos;origine della transizione dallo stato &apos;%1&apos;</translation>
    </message>
</context>
<context>
    <name>QMdiArea</name>
    <message>
        <source>(Untitled)</source>
        <translation>(Senza titolo)</translation>
    </message>
</context>
<context>
    <name>QDeclarativeXmlListModelRole</name>
    <message>
        <source>An XmlRole query must not start with &apos;/&apos;</source>
        <translation>Un&apos;interrogazione XmlRole non può cominciare per &apos;/&apos;</translation>
    </message>
</context>
<context>
    <name>QDeclarativeBehavior</name>
    <message>
        <source>Cannot change the animation assigned to a Behavior.</source>
        <translation>Impossibile cambiare l&apos;animazione assegnata a un comportamento.</translation>
    </message>
</context>
<context>
    <name>Q3Accel</name>
    <message>
        <source>%1, %2 not defined</source>
        <translation>%1, %2 non definiti</translation>
    </message>
    <message>
        <source>Ambiguous %1 not handled</source>
        <translation>%1 ambiguo non gestito</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::EffectFactory</name>
    <message>
        <source>Enabled</source>
        <translation>Abilitato</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::DsaVideoPlayer</name>
    <message>
        <source>Video display error</source>
        <translation>Errore nella visualizzazione del video</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::SurfaceVideoPlayer</name>
    <message>
        <source>Video display error</source>
        <translation>Errore nella visualizzazione del video</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::StereoWidening</name>
    <message>
        <source>Level (%)</source>
        <translation>Livello (%)</translation>
    </message>
</context>
<context>
    <name>Phonon::MMF::AudioPlayer</name>
    <message>
        <source>Getting position failed</source>
        <translation>Recupero della posizione non riuscito</translation>
    </message>
</context>
<context>
    <name>QDeclarativeKeyNavigationAttached</name>
    <message>
        <source>KeyNavigation is only available via attached properties</source>
        <translation>KeyNavigation è disponibile solo attraverso proprietà allegate</translation>
    </message>
</context>
<context>
    <name>QDeclarativeAnchorAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation>Impossibile impostare una durata negativa</translation>
    </message>
</context>
<context>
    <name>QDeclarativePauseAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation>Impossibile impostare una durata negativa</translation>
    </message>
</context>
<context>
    <name>QDeclarativePropertyAnimation</name>
    <message>
        <source>Cannot set a duration of &lt; 0</source>
        <translation>Impossibile impostare una durata negativa</translation>
    </message>
</context>
<context>
    <name>QTcpServer</name>
    <message>
        <source>Operation on socket is not supported</source>
        <translation>L&apos;operazione sul socket non è supportata</translation>
    </message>
</context>
<context>
    <name>QDeclarativeXmlListModel</name>
    <message>
        <source>Qt was built without support for xmlpatterns</source>
        <translation>Qt è stato generato senza supporto per gli schemi XML</translation>
    </message>
</context>
</TS>

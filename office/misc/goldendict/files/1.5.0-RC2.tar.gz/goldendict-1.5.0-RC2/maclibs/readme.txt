This directory holds precompiled third-party libraries and their header files
used to build GoldenDict under Mac OS X. Those are supplied merely to ease
the build process. No other platform except Mac OS X uses those files, so they
can safely be removed for Linux builds etc.
Due credit goes to those created those libraries. The libraries are
copyrighted by their responsive copyright holders and distributed in
compliance to their respective licenses. No modifications were made except
those needed in order to build the libraries correctly. The source codes
aren't shipped here merely to shrink the size of the distribution, and can
be downloaded from the original libraries' websites separately.

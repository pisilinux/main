// This is a standard way (e.g., in KDE libs) of dealing
// with X11 headers mess.

#ifdef Unsorted
#undef Unsorted
#endif

#ifdef None
#undef None
#endif

#ifdef Bool
#undef Bool
#endif

#ifdef FontChange
#undef FontChange
#endif

#ifdef KeyPress
#undef KeyPress
#endif

#ifdef KeyRelease
#undef KeyRelease
#endif

#ifdef Above
#undef Above
#endif

#ifdef Below
#undef Below
#endif

#ifdef FocusIn
#undef FocusIn
#endif

#ifdef FocusOut
#undef FocusOut
#endif

#ifdef Always
#undef Always
#endif

#ifdef Success
#undef Success
#endif

#ifdef GrayScale
#undef GrayScale
#endif

#ifdef Status
#undef Status
#endif

#ifdef CursorShape
#undef CursorShape
#endif


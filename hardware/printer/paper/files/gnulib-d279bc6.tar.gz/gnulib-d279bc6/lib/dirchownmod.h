#include <sys/types.h>
int dirchownmod (int, char const *, mode_t, uid_t, gid_t, mode_t, mode_t);

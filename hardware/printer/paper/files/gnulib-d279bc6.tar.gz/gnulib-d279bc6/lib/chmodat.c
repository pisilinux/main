#include <config.h>
#define CHMODAT_INLINE _GL_EXTERN_INLINE
#include "openat.h"

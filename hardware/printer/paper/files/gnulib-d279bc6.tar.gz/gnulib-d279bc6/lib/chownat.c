#include <config.h>
#define CHOWNAT_INLINE _GL_EXTERN_INLINE
#include "openat.h"
